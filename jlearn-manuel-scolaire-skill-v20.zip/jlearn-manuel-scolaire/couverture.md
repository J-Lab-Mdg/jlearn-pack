# Page de couverture

La couverture est la **première page du `.docx`**, avant le sommaire.

---

## 1. Maquettes disponibles

Les maquettes sont versionnées dans le dépôt GitHub lié au projet
(`J-Lab-Mdg/jlearn-pack`, branche `main`). **Toujours partir d'une maquette
existante** : le personnage, la salle de classe et le logo J-Learn constituent
l'identité visuelle de la collection.

| Fichier | Dimensions | Personnage | Mot au tableau | Langue |
|---|---|---|---|---|
| `bookcover MATH T6 contenu pe.png` | 843 × 1264 | **homme** | CONTENU PE | français |
| `bookcovers1.png` | 1029 × 1528 | femme | CONTENU PS | français |
| `bookcovers2.png` | 1029 × 1528 | femme | CONTENU PS | français |
| `bookcovers3.png` | 1024 × 1536 | femme | Contenu | français |
| `bookcovers4.png` | 1023 × 1537 | femme | Content | **anglais** |
| `bookcovers5.png` | 1029 × 1529 | femme | CONTENU PE | français |
| `bookcovers6.png` | 1024 × 1536 | femme | Contenu | français |

```bash
git fetch origin main
git checkout origin/main -- bookcovers3.png
```

### Choix du personnage — question à poser

Le personnage change de sexe selon le livre. **Demander à l'utilisateur, pour
chaque manuel, s'il veut un enseignant ou une enseignante** (voir SKILL.md,
Étape 0). Ne jamais le supposer.

Limite actuelle à connaître avant de promettre quoi que ce soit : **une seule
maquette masculine existe** (`bookcover MATH T6 contenu pe.png`), et elle est
plus petite que les autres (843 × 1264). Si l'utilisateur demande un homme pour
un autre manuel, deux options seulement : réutiliser cette maquette, ou lui
demander d'en fournir une nouvelle. Ne pas fabriquer un personnage par IA — il
ne correspondrait pas à l'identité de la collection.

### Mot écrit au tableau — question à poser

Le mot est **« CONTENU PE » ou « CONTENU PS »** selon le manuel. C'est un choix
de l'utilisateur, à poser à l'Étape 0, jamais déduit de la matière.

Pour un manuel en anglais, partir de `bookcovers4.png`, dont l'en-tête et la
liste sont déjà en anglais.

## 2. Ne jamais supposer les dimensions

Les maquettes n'ont pas la même taille :

| Fichier | Dimensions |
|---------|-----------|
| `bookcovers1.png`, `bookcovers2.png` | 1029 × 1528 |
| `bookcovers3.png`, `bookcovers6.png` | 1024 × 1536 |
| `bookcovers4.png` | 1023 × 1537 |
| `bookcovers5.png` | 1029 × 1529 |
| `bookcover MATH T6 contenu pe.png` | 843 × 1264 |

Elles n'ont pas non plus la même composition : `bookcovers3.png` porte le titre
sur **deux** bandes (matière puis niveau), `bookcovers6.png` sur **une** seule.
Écrire le niveau à l'emplacement attendu y détruirait le slogan.

**Conséquence : mesurer avant de retoucher, systématiquement.**

```bash
python3 scripts/couverture.py bookcovers3.png --mesurer
```

---

## 3. Adapter la maquette

```bash
python3 scripts/couverture.py bookcovers3.png couverture-SVT-T9.png \
    --titre SVT --niveau T9 --tableau "CONTENU PE"
```

Si l'en-tête n'a pas quatre bandes, le script refuse de deviner et demande les
index explicites (`--bande-titre`, `--bande-niveau`).

### Ce qui se modifie et ce qui ne se modifie pas

Seuls les **textes** changent : la matière, le niveau, et le mot écrit à la
craie. Le personnage, la liste au tableau, la salle, le logo et le slogan
restent intacts. Le script le vérifie lui-même et affiche :

    pixels modifiés hors zones de texte : 0

Si ce nombre n'est pas nul, **ne pas livrer**.

### Pourquoi une diffusion de Laplace pour effacer la craie

Le tableau vert porte un dégradé de lumière — de `(64,77,65)` en haut à gauche
à `(19,23,19)` en bas. Deux approches ont été essayées et écartées :

- **remplir d'un vert uni** : laisse un rectangle visible ;
- **recopier une zone voisine** : importe le cadre en bois quand la zone source
  déborde du tableau, et traîne les jambages des lettres en bandes verticales.

La diffusion de Laplace ne propage que les pixels sains du pourtour et
reconstitue le dégradé sans couture.

---

## 4. Typographie

### Nom de la matière — abréviation à faire valider

La maquette réserve une ligne courte au nom de la matière. Les intitulés longs
(« Physique-Chimie », « Histoire-Géographie », « Sciences de la vie et de la
terre ») n'y tiennent pas à hauteur de capitale constante.

**Ne pas réduire le corps du texte pour faire entrer le nom** : la ligne
deviendrait visuellement plus faible que le niveau placé en dessous. Utiliser
une abréviation, et **la faire valider par l'utilisateur** (Étape 0) plutôt que
de l'inventer — les usages varient d'un établissement à l'autre.

Exemples observés : `SVT`, `PC`, `HG`, `MATH`.

---

Les maquettes emploient une grotesque condensée (type Montserrat). Si seule
DejaVu Sans Bold est disponible, le texte redessiné sera **plus large** que
l'original à hauteur de capitale égale. C'est acceptable, mais doit être
**signalé à l'utilisateur** — ou corrigé en déposant la police voulue dans le
dépôt.

Le centrage se fait sur le milieu réel de l'image. Attention : le logo J-Learn
occupe le coin haut droit ; l'inclure dans la boîte englobante fausse le calcul
et donne une impression de décentrage là où il n'y en a pas.

---

## 5. Insertion dans le `.docx`

La couverture occupe une pleine page, suivie d'un saut de page :

```python
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.space_before = Pt(0)
p.paragraph_format.space_after = Pt(0)
p.add_run().add_picture(couverture, height=Cm(26.1))   # A4 moins les marges
doc.add_page_break()
```

Caler l'image sur la **hauteur** utile (29,7 − 2 × 1,8 = 26,1 cm) et laisser la
largeur suivre : caler sur la largeur déborderait en hauteur et produirait une
seconde page blanche.

Vérifier après génération que la largeur obtenue tient dans la largeur utile
(21 − 2 × 1,5 = 18 cm) ; pour un rapport 1024/1536, elle vaut 17,4 cm.
