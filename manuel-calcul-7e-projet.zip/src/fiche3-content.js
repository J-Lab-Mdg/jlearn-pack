// Fiche 3 — Arithmétique — Nombres de 0 à 999 999 999 (classe Million + Mille + Unités)
// Mois 1, 5 séances

module.exports = {
  meta: {
    discipline: "Mathématiques",
    sousDiscipline: "Arithmétique",
    theme: "Les nombres jusqu'au milliard",
    titre: "Les nombres de 0 à 999 999 999",
    objectif: "Lire, écrire, décomposer, comparer, ranger et résoudre des problèmes avec des nombres de 0 à 999 999 999",
    documentation: "Programme officiel de Calcul, classe de 7e (page 89)",
    support: "Tableau de numération à trois classes, tableau noir, cahier",
    classe: "7e",
    seance: "8 à 12",
    duree: "5 séances de 30 min",
  },

  revision: {
    questions: [
      { q: "Comment lit-on 302 040 ?", ra: "On lit « trois cent deux mille quarante »." },
      { q: "Le mot « mille » change-t-il au pluriel ?", ra: "Non, « mille » ne change jamais : ni « un mille », ni « milles »." },
    ],
  },

  miseEnSituation: {
    histoire: "Selon les chiffres officiels, Madagascar compte environ 29 millions d'habitants. Koto lit ce nombre dans son livre d'histoire-géographie : « 29 000 000 ». Il compte les zéros un à un, mais il aimerait comprendre comment lire ce nombre sans les compter à chaque fois.",
  },

  presentation: {
    texte: "Aujourd'hui nous allons apprendre : « Les nombres de 0 à 999 999 999 ». Après cette séance, vous serez capables de lire, écrire, décomposer, comparer et ranger des nombres jusqu'à neuf chiffres.",
  },

  observation: {
    support: "le tableau de numération à trois classes affiché au tableau noir : Million (C-D-U), Mille (C-D-U), Unités (C-D-U)",
    consigne: "Regardez et observez bien ce tableau : une troisième classe, la classe des Millions, a été ajoutée à gauche.",
  },

  analyse: {
    questions: [
      { q: "Combien de classes voyez-vous maintenant ?", ra: "Trois classes : Millions, Mille, Unités." },
      { q: "Dans 29 000 000, quel chiffre est dans la classe des Millions ?", ra: "29 est dans la classe des Millions (la classe Mille et la classe Unités valent 000)." },
      { q: "Comment lit-on 1 000 000 ?", ra: "On lit « un million » : contrairement à « mille », le mot « million » prend bien « un » devant lui." },
      { q: "Comment lit-on 2 000 000 ?", ra: "On lit « deux millions » : le mot « million » prend un « s » au pluriel, contrairement à « mille »." },
      { q: "Comment lit-on 305 764 502 ?", ra: "On lit « trois cent cinq millions sept cent soixante-quatre mille cinq cent deux »." },
    ],
  },

  synthese: {
    texte: "Donc, pour lire un nombre de 0 à 999 999 999, on le sépare en trois classes de trois chiffres : Millions, Mille, Unités, séparées par un espace. On lit chaque classe comme un nombre de 0 à 999, en ajoutant le nom de la classe. Attention : « million » est un vrai nom, il prend « un » devant lui (un million) et un « s » au pluriel (deux millions), contrairement à « mille » qui ne change jamais.",
  },

  numerationExamples: [
    { nombre: "305 764 502", classeMi: "305", classeM: "764", classeU: "502", lettres: "trois cent cinq millions sept cent soixante-quatre mille cinq cent deux" },
    { nombre: "1 000 000", classeMi: "001", classeM: "000", classeU: "000", lettres: "un million" },
    { nombre: "2 000 000", classeMi: "002", classeM: "000", classeU: "000", lettres: "deux millions" },
    { nombre: "29 000 000", classeMi: "029", classeM: "000", classeU: "000", lettres: "vingt-neuf millions" },
    { nombre: "150 020 300", classeMi: "150", classeM: "020", classeU: "300", lettres: "cent cinquante millions vingt mille trois cents" },
  ],

  decompositionExamples: [
    { nombre: "305 764 502", decomp: "300 000 000 + 5 000 000 + 700 000 + 60 000 + 4 000 + 500 + 2" },
    { nombre: "150 020 300", decomp: "100 000 000 + 50 000 000 + 20 000 + 300" },
  ],

  comparaisonExamples: [
    { a: "305 764 502", b: "29 000 000", signe: ">", explication: "305 764 502 a neuf chiffres, 29 000 000 en a huit (moins de chiffres = nombre plus petit), donc 305 764 502 > 29 000 000." },
    { a: "150 020 300", b: "150 020 030", signe: ">", explication: "Les classes Millions (150) et une partie de la classe Mille sont identiques ; on compare finement : 020 300 > 020 030, donc 150 020 300 > 150 020 030." },
  ],

  rangementExample: {
    nombres: ["305 764 502", "29 000 000", "150 020 300", "2 000 000"],
    croissant: "2 000 000 < 29 000 000 < 150 020 300 < 305 764 502",
    decroissant: "305 764 502 > 150 020 300 > 29 000 000 > 2 000 000",
  },

  applicationExercices: [
    {
      titre: "Exercice 1 — Lecture et écriture",
      consigne: "Écris en lettres les nombres suivants.",
      items: ["a) 4 000 000", "b) 12 500 000", "c) 700 003 000"],
      corrige: ["a) quatre millions", "b) douze millions cinq cent mille", "c) sept cent millions trois mille"],
    },
    {
      titre: "Exercice 2 — Décomposition",
      consigne: "Décompose chaque nombre selon ses classes et ses chiffres.",
      items: ["a) 3 040 200", "b) 82 000 015"],
      corrige: ["a) 3 040 200 = 3 000 000 + 40 000 + 200", "b) 82 000 015 = 80 000 000 + 2 000 000 + 15"],
    },
  ],

  evaluationExercices: [
    {
      titre: "Exercice 1 — Lecture et écriture",
      consigne: "Écris en chiffres les nombres suivants.",
      items: [
        "a) neuf millions cinquante mille",
        "b) un million deux cents",
        "c) trois cent millions",
      ],
      corrige: ["a) 9 050 000", "b) 1 000 200", "c) 300 000 000"],
    },
    {
      titre: "Exercice 2 — Comparaison et rangement",
      consigne: "Compare avec le signe qui convient, puis range dans l'ordre croissant.",
      items: [
        "a) 6 200 000 ... 620 000",
        "b) Range dans l'ordre croissant : 45 000 000, 4 500 000, 450 000 000, 450 000",
      ],
      corrige: [
        "a) 6 200 000 > 620 000",
        "b) 450 000 < 4 500 000 < 45 000 000 < 450 000 000",
      ],
    },
  ],

  attention: "« million » n'est pas comme « mille » : c'est un vrai nom qui prend « un » devant lui (un million, jamais juste « million ») et un « s » au pluriel (trois millions). Attention aussi au nombre de chiffres : un nombre à neuf chiffres est toujours plus grand qu'un nombre à huit chiffres ou moins, même si le premier chiffre semble petit (ex. 100 000 000 a neuf chiffres et est plus grand que 99 000 000 qui n'en a que huit).",
};
