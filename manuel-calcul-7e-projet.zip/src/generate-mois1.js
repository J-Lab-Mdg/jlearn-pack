const fs = require("fs");
const { Document, AlignmentType } = require("./builders.js");
const {
  Packer, buildLeconNumeration, buildLeconGeometrie, buildLeconMesureConversion,
  buildLeconConcept, assembleFiche,
} = require("./fiche-templates.js");

const fiche1 = require("./fiche1-content.js");
const fiche2 = require("./fiche2-content.js");
const fiche3 = require("./fiche3-content.js");
const fiche4 = require("./fiche4-content.js");
const fiche5 = require("./fiche5-content.js");
const fiche6 = require("./fiche6-content.js");
const fiche7 = require("./fiche7-content.js");
const fiche8 = require("./fiche8-content.js");
const fiche9 = require("./fiche9-content.js");

const TOTAL = 81;

let children = [];

children.push(...assembleFiche(fiche1, {
  seanceLabel: "1", totalFiches: TOTAL, first: true,
  dureeI: "3 min", dureeII: "20 min", dureeIII: "7 min",
  buildLeconBody: (c) => buildLeconNumeration(c, [{ label: "C", key: "c" }, { label: "D", key: "d" }, { label: "U", key: "u" }]),
}));

children.push(...assembleFiche(fiche2, {
  seanceLabel: "2", totalFiches: TOTAL,
  dureeI: "10 min", dureeII: "60 min", dureeIII: "20 min",
  buildLeconBody: (c) => buildLeconNumeration(c, [{ label: "Mille", key: "classeM" }, { label: "Unités", key: "classeU" }]),
}));

children.push(...assembleFiche(fiche3, {
  seanceLabel: "3", totalFiches: TOTAL,
  dureeI: "12 min", dureeII: "75 min", dureeIII: "25 min",
  buildLeconBody: (c) => buildLeconNumeration(c, [{ label: "Million", key: "classeMi" }, { label: "Mille", key: "classeM" }, { label: "Unités", key: "classeU" }]),
}));

children.push(...assembleFiche(fiche4, {
  seanceLabel: "4", totalFiches: TOTAL,
  dureeI: "15 min", dureeII: "90 min", dureeIII: "30 min",
  buildLeconBody: (c) => buildLeconNumeration(c, [{ label: "Milliard", key: "classeMd" }, { label: "Million", key: "classeMi" }, { label: "Mille", key: "classeM" }, { label: "Unités", key: "classeU" }]),
}));

children.push(...assembleFiche(fiche5, {
  seanceLabel: "5", totalFiches: TOTAL,
  dureeI: "3 min", dureeII: "20 min", dureeIII: "7 min",
  buildLeconBody: buildLeconGeometrie,
}));

children.push(...assembleFiche(fiche6, {
  seanceLabel: "6", totalFiches: TOTAL,
  dureeI: "3 min", dureeII: "20 min", dureeIII: "7 min",
  buildLeconBody: buildLeconGeometrie,
}));

children.push(...assembleFiche(fiche7, {
  seanceLabel: "7", totalFiches: TOTAL,
  dureeI: "3 min", dureeII: "20 min", dureeIII: "7 min",
  buildLeconBody: buildLeconGeometrie,
}));

children.push(...assembleFiche(fiche8, {
  seanceLabel: "8", totalFiches: TOTAL,
  dureeI: "10 min", dureeII: "60 min", dureeIII: "20 min",
  buildLeconBody: buildLeconMesureConversion,
}));

children.push(...assembleFiche(fiche9, {
  seanceLabel: "9", totalFiches: TOTAL,
  dureeI: "3 min", dureeII: "20 min", dureeIII: "7 min",
  buildLeconBody: buildLeconConcept,
}));

const doc = new Document({ sections: [{ properties: {}, children }] });

Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync("./output/Mois1-Complet.docx", buf);
  console.log("Fichier généré : output/Mois1-Complet.docx");
});
