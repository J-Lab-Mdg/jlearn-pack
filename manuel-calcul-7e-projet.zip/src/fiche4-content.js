// Fiche 4 — Arithmétique — Nombres de 0 à 999 999 999 999 (classe Milliard + Million + Mille + Unités)
// Mois 1, 6 séances

module.exports = {
  meta: {
    discipline: "Mathématiques",
    sousDiscipline: "Arithmétique",
    theme: "Les nombres jusqu'au milliard",
    titre: "Les nombres de 0 à 999 999 999 999",
    objectif: "Lire, écrire, décomposer, comparer, ranger et résoudre des problèmes avec des nombres jusqu'au milliard",
    documentation: "Programme officiel de Calcul, classe de 7e (page 89)",
    support: "Tableau de numération à quatre classes, tableau noir, cahier",
    classe: "7e",
    seance: "13 à 18",
    duree: "6 séances de 30 min",
  },

  revision: {
    questions: [
      { q: "Comment lit-on 2 000 000 ?", ra: "On lit « deux millions »." },
      { q: "« Million » prend-il un « s » au pluriel ?", ra: "Oui, contrairement à « mille » qui ne change jamais." },
    ],
  },

  miseEnSituation: {
    histoire: "Dans le journal, Nivo lit que le budget national de Madagascar pour l'année dépasse 7 000 000 000 000 d'ariary. Elle n'a jamais vu un nombre aussi long et se demande combien de classes il contient et comment le lire.",
  },

  presentation: {
    texte: "Aujourd'hui nous allons apprendre : « Les nombres de 0 à 999 999 999 999 ». Après cette séance, vous serez capables de lire, écrire, décomposer, comparer et ranger des nombres jusqu'à douze chiffres, c'est-à-dire jusqu'au milliard.",
  },

  observation: {
    support: "le tableau de numération à quatre classes affiché au tableau noir : Milliard (C-D-U), Million (C-D-U), Mille (C-D-U), Unités (C-D-U)",
    consigne: "Regardez et observez bien ce tableau : une quatrième classe, la classe des Milliards, a été ajoutée à gauche.",
  },

  analyse: {
    questions: [
      { q: "Combien de classes voyez-vous maintenant ?", ra: "Quatre classes : Milliards, Millions, Mille, Unités." },
      { q: "Combien de chiffres au maximum peut avoir un nombre dans ce tableau ?", ra: "Douze chiffres au maximum (quatre classes de trois chiffres)." },
      { q: "Comment lit-on 1 000 000 000 ?", ra: "On lit « un milliard » : comme « million », le mot « milliard » prend « un » devant lui." },
      { q: "« Milliard » prend-il un « s » au pluriel ?", ra: "Oui : on dit « sept milliards » avec un « s », comme pour « million »." },
      { q: "Comment lit-on 512 034 007 128 ?", ra: "On lit « cinq cent douze milliards trente-quatre millions sept mille cent vingt-huit »." },
    ],
  },

  synthese: {
    texte: "Donc, pour lire un nombre jusqu'au milliard, on le sépare en quatre classes de trois chiffres : Milliards, Millions, Mille, Unités, séparées par un espace. On lit chaque classe comme un nombre de 0 à 999, en ajoutant le nom de la classe (sauf si elle vaut 000, on ne dit rien). « Milliard », comme « million », prend « un » devant lui et un « s » au pluriel. « Mille » ne change jamais.",
  },

  numerationExamples: [
    { nombre: "512 034 007 128", classeMd: "512", classeMi: "034", classeM: "007", classeU: "128", lettres: "cinq cent douze milliards trente-quatre millions sept mille cent vingt-huit" },
    { nombre: "1 000 000 000", classeMd: "001", classeMi: "000", classeM: "000", classeU: "000", lettres: "un milliard" },
    { nombre: "7 000 000 000", classeMd: "007", classeMi: "000", classeM: "000", classeU: "000", lettres: "sept milliards" },
    { nombre: "20 305 000 000", classeMd: "020", classeMi: "305", classeM: "000", classeU: "000", lettres: "vingt milliards trois cent cinq millions" },
  ],

  decompositionExamples: [
    { nombre: "512 034 007 128", decomp: "500 000 000 000 + 12 000 000 000 + 34 000 000 + 7 000 + 100 + 20 + 8" },
    { nombre: "7 000 000 000", decomp: "7 000 000 000" },
  ],

  comparaisonExamples: [
    { a: "512 034 007 128", b: "20 305 000 000", signe: ">", explication: "512 034 007 128 a douze chiffres, 20 305 000 000 en a onze, donc 512 034 007 128 > 20 305 000 000." },
    { a: "7 000 000 000", b: "1 000 000 000", signe: ">", explication: "Les deux nombres ont dix chiffres ; on compare le chiffre des milliards : 7 > 1, donc 7 000 000 000 > 1 000 000 000." },
  ],

  rangementExample: {
    nombres: ["512 034 007 128", "7 000 000 000", "20 305 000 000", "1 000 000 000"],
    croissant: "1 000 000 000 < 7 000 000 000 < 20 305 000 000 < 512 034 007 128",
    decroissant: "512 034 007 128 > 20 305 000 000 > 7 000 000 000 > 1 000 000 000",
  },

  applicationExercices: [
    {
      titre: "Exercice 1 — Lecture et écriture",
      consigne: "Écris en lettres les nombres suivants.",
      items: ["a) 3 000 000 000", "b) 15 200 000 000", "c) 6 000 000 500"],
      corrige: ["a) trois milliards", "b) quinze milliards deux cents millions", "c) six milliards cinq cents"],
    },
    {
      titre: "Exercice 2 — Décomposition",
      consigne: "Décompose chaque nombre selon ses classes.",
      items: ["a) 4 020 000 000", "b) 100 000 000 300"],
      corrige: ["a) 4 020 000 000 = 4 000 000 000 + 20 000 000", "b) 100 000 000 300 = 100 000 000 000 + 300"],
    },
  ],

  evaluationExercices: [
    {
      titre: "Exercice 1 — Lecture et écriture",
      consigne: "Écris en chiffres les nombres suivants.",
      items: [
        "a) deux milliards cinquante millions",
        "b) neuf milliards",
        "c) un milliard trois cent mille",
      ],
      corrige: ["a) 2 050 000 000", "b) 9 000 000 000", "c) 1 000 300 000"],
    },
    {
      titre: "Exercice 2 — Comparaison et rangement",
      consigne: "Compare avec le signe qui convient, puis range dans l'ordre décroissant.",
      items: [
        "a) 3 200 000 000 ... 320 000 000",
        "b) Range dans l'ordre décroissant : 500 000 000, 5 000 000 000, 50 000 000, 5 000 000",
      ],
      corrige: [
        "a) 3 200 000 000 > 320 000 000",
        "b) 5 000 000 000 > 500 000 000 > 50 000 000 > 5 000 000",
      ],
    },
  ],

  attention: "« milliard » se comporte comme « million » : il prend « un » devant lui (un milliard) et un « s » au pluriel (cinq milliards) — jamais comme « mille » qui ne change jamais. Le plus sûr pour comparer deux très grands nombres est de compter d'abord le nombre total de chiffres : celui qui en a le plus est toujours le plus grand, quel que soit son premier chiffre.",
};
