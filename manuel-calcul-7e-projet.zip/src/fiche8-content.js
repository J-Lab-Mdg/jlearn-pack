// Fiche 8 — Mesure — Unités de mesure de longueur
// Mois 1, 4 séances

module.exports = {
  meta: {
    discipline: "Mathématiques",
    sousDiscipline: "Mesure",
    theme: "Mesures de longueur",
    titre: "Les unités de mesure de longueur",
    objectif: "Connaître les unités de longueur et convertir une mesure d'une unité à une autre",
    documentation: "Programme officiel de Calcul, classe de 7e",
    support: "Tableau des unités de longueur, mètre ruban, tableau noir",
    classe: "7e",
    seance: "25 à 28",
    duree: "4 séances de 30 min",
  },

  revision: {
    questions: [
      { q: "Quelle unité utilise-t-on pour mesurer la longueur d'un cahier ?", ra: "Le centimètre." },
      { q: "Quelle unité utilise-t-on pour mesurer la distance entre deux villes ?", ra: "Le kilomètre." },
    ],
  },

  miseEnSituation: {
    histoire: "Lova va au marché pour acheter 3,45 mètres de tissu pour coudre une robe. Le vendeur mesure avec son mètre ruban gradué en centimètres. Lova doit vérifier si le vendeur lui a donné la bonne quantité en centimètres.",
  },

  presentation: {
    texte: "Aujourd'hui nous allons apprendre : « Les unités de mesure de longueur ». Après cette séance, vous serez capables de connaître les unités de longueur et de convertir une mesure d'une unité à une autre.",
  },

  observation: {
    support: "le tableau des unités de longueur affiché au tableau noir : km, hm, dam, m, dm, cm, mm",
    consigne: "Regardez et observez bien ce tableau : chaque colonne représente une unité, dix fois plus petite que sa voisine de gauche.",
  },

  analyse: {
    questions: [
      { q: "Combien d'unités voyez-vous dans ce tableau ?", ra: "Sept unités : km, hm, dam, m, dm, cm, mm." },
      { q: "Combien de mètres y a-t-il dans 1 kilomètre ?", ra: "1 km = 1 000 m." },
      { q: "Pour convertir 3,45 km en mètres, que doit-on faire ?", ra: "On déplace la virgule de trois rangs vers la droite (car on va vers une unité plus petite), ce qui donne 3 450 m." },
      { q: "Pour convertir 250 cm en mètres, que doit-on faire ?", ra: "On déplace la virgule de deux rangs vers la gauche (car on va vers une unité plus grande), ce qui donne 2,50 m." },
    ],
  },

  synthese: {
    texte: "Donc, les unités de longueur, du plus grand au plus petit, sont : km, hm, dam, m, dm, cm, mm. Chaque unité vaut 10 fois l'unité suivante. Pour convertir vers une unité plus petite, on déplace la virgule vers la droite ; pour convertir vers une unité plus grande, on déplace la virgule vers la gauche, d'autant de rangs que de colonnes parcourues dans le tableau.",
  },

  tableauConversion: {
    unites: ["km", "hm", "dam", "m", "dm", "cm", "mm"],
    exemples: [
      { valeur: "3,45 km = 3 450 m", chiffres: ["3", ",", "4", "5", "0"], colonneDepart: 0 },
      { valeur: "250 cm = 2,50 m", chiffres: ["2", ",", "5", "0"], colonneDepart: 3 },
      { valeur: "7 m 5 cm = 7,05 m", chiffres: ["7", ",", "0", "5"], colonneDepart: 3 },
    ],
  },

  reglePratique: "Pour convertir, on place le chiffre des unités de la mesure de départ dans sa colonne du tableau, puis on complète avec des zéros si besoin jusqu'à la colonne de l'unité d'arrivée, en ajoutant la virgule à cette dernière position.",

  applicationExercices: [
    {
      titre: "Exercice 1 — Conversion vers une unité plus petite",
      consigne: "Convertis en mètres.",
      items: ["a) 0,008 km", "b) 12 dam"],
      corrige: ["a) 0,008 km = 8 m", "b) 12 dam = 120 m"],
    },
    {
      titre: "Exercice 2 — Conversion vers une unité plus grande",
      consigne: "Convertis en mètres.",
      items: ["a) 1 250 cm", "b) 45 dm"],
      corrige: ["a) 1 250 cm = 12,50 m", "b) 45 dm = 4,5 m"],
    },
  ],

  evaluationExercices: [
    {
      titre: "Exercice 1 — Conversions",
      consigne: "Convertis les mesures suivantes.",
      items: [
        "a) 5,2 km en m",
        "b) 630 cm en m",
        "c) 8 m en mm",
      ],
      corrige: ["a) 5,2 km = 5 200 m", "b) 630 cm = 6,30 m", "c) 8 m = 8 000 mm"],
    },
    {
      titre: "Exercice 2 — Problème",
      consigne: "Le vendeur de Lova a mesuré 345 cm de tissu. Est-ce la même quantité que 3,45 m demandés par Lova ? Justifie.",
      items: ["Réponse et justification"],
      corrige: ["a) Oui : 345 cm = 3,45 m (on déplace la virgule de deux rangs vers la gauche), c'est la même quantité."],
    },
  ],

  attention: "le piège le plus fréquent est de se tromper dans le nombre de rangs à déplacer la virgule : il faut toujours compter précisément le nombre de colonnes entre l'unité de départ et l'unité d'arrivée dans le tableau, jamais déplacer la virgule « au hasard » d'un ou deux rangs.",
};
