// Fiche 9 — Mesure — L'échelle sur une carte
// Mois 1, 2 séances

module.exports = {
  meta: {
    discipline: "Mathématiques",
    sousDiscipline: "Mesure",
    theme: "Mesures de longueur",
    titre: "L'échelle sur une carte",
    objectif: "Comprendre la notion d'échelle et calculer une distance réelle à partir d'une carte",
    documentation: "Programme officiel de Calcul, classe de 7e",
    support: "Carte de Madagascar, règle graduée, tableau noir",
    classe: "7e",
    seance: "29 à 30",
    duree: "2 séances de 30 min",
  },

  revision: {
    questions: [
      { q: "Combien de mètres y a-t-il dans 1 kilomètre ?", ra: "1 km = 1 000 m." },
      { q: "Combien de centimètres y a-t-il dans 1 mètre ?", ra: "1 m = 100 cm." },
    ],
  },

  miseEnSituation: {
    histoire: "Sur la carte de Madagascar affichée en classe, Tiana mesure avec sa règle 4 cm entre Antananarivo et une ville voisine. Sur la carte est écrit « Échelle : 1/50 000 ». Tiana se demande quelle est la vraie distance entre les deux villes.",
  },

  presentation: {
    texte: "Aujourd'hui nous allons apprendre : « L'échelle sur une carte ». Après cette séance, vous serez capables de comprendre ce que signifie une échelle et de calculer une distance réelle à partir d'une mesure sur une carte.",
  },

  observation: {
    support: "la carte de Madagascar affichée avec son échelle indiquée « 1/50 000 »",
    consigne: "Regardez et observez bien cette carte et l'indication d'échelle écrite en bas.",
  },

  analyse: {
    questions: [
      { q: "Que signifie « 1/50 000 » écrit sur la carte ?", ra: "Cela signifie que 1 cm mesuré sur la carte représente 50 000 cm dans la réalité." },
      { q: "Tiana a mesuré 4 cm sur la carte. Combien cela fait-il de centimètres réels ?", ra: "4 × 50 000 = 200 000 cm dans la réalité." },
      { q: "200 000 cm, combien cela fait-il de kilomètres ?", ra: "200 000 cm = 2 000 m = 2 km." },
    ],
  },

  synthese: {
    texte: "Donc, l'échelle d'une carte indique le rapport entre une distance mesurée sur la carte et la distance réelle correspondante. Une échelle « 1/n » signifie que 1 cm sur la carte représente n cm dans la réalité. Pour trouver la distance réelle, on multiplie la distance mesurée sur la carte (en cm) par le dénominateur n de l'échelle, puis on convertit le résultat en mètres ou en kilomètres si besoin.",
  },

  exempleResolu: {
    enonce: "Sur une carte à l'échelle 1/50 000, la distance entre deux villages mesure 4 cm. Calcule la distance réelle en kilomètres.",
    etapes: [
      "Distance réelle (en cm) = distance sur la carte × dénominateur de l'échelle",
      "Distance réelle = 4 × 50 000",
      "Distance réelle = 200 000 cm",
      "200 000 cm = 2 000 m = 2 km",
    ],
  },

  applicationExercices: [
    {
      titre: "Exercice 1 — Calcul de distance réelle",
      consigne: "Sur une carte à l'échelle 1/25 000, deux villages sont distants de 6 cm. Calcule la distance réelle en km.",
      items: ["Distance réelle = ?"],
      corrige: ["a) 6 × 25 000 = 150 000 cm = 1,5 km"],
    },
    {
      titre: "Exercice 2 — Calcul de distance réelle",
      consigne: "Sur une carte à l'échelle 1/100 000, une rivière mesure 2,5 cm. Calcule sa longueur réelle en km.",
      items: ["Distance réelle = ?"],
      corrige: ["a) 2,5 × 100 000 = 250 000 cm = 2,5 km"],
    },
  ],

  evaluationExercices: [
    {
      titre: "Exercice 1 — Problème",
      consigne: "Sur une carte à l'échelle 1/50 000, la distance entre deux écoles mesure 3 cm. Quelle est la distance réelle en km ?",
      items: ["Distance réelle = ?"],
      corrige: ["a) 3 × 50 000 = 150 000 cm = 1,5 km"],
    },
    {
      titre: "Exercice 2 — Problème inverse",
      consigne: "La distance réelle entre deux villes est de 15 km. Sur une carte à l'échelle 1/50 000, quelle sera la distance mesurée sur la carte, en cm ?",
      items: ["Distance sur la carte = ?"],
      corrige: ["a) 15 km = 1 500 000 cm ; 1 500 000 ÷ 50 000 = 30 cm"],
    },
  ],

  attention: "toujours convertir la distance mesurée sur la carte en centimètres avant de multiplier par le dénominateur de l'échelle, et bien reconvertir le résultat final en mètres ou en kilomètres — un résultat en centimètres pour une distance entre deux villes n'a pas de sens pratique.",
};
