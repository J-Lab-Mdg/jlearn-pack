// Fiche 1 — Arithmétique — Nombres de 0 à 999 (classe des Unités : C-D-U)
// Mois 1, 3 séances (sur 18 séances totales du bloc "Nombres jusqu'au milliard")

module.exports = {
  meta: {
    discipline: "Mathématiques",
    sousDiscipline: "Arithmétique",
    theme: "Les nombres jusqu'au milliard",
    titre: "Les nombres de 0 à 999",
    objectif: "Lire, écrire, décomposer, comparer, ranger et résoudre des problèmes avec des nombres de 0 à 999",
    documentation: "Programme officiel de Calcul, classe de 7e (page 89)",
    support: "Tableau de numération, tableau noir, cahier",
    classe: "7e",
    seance: "1 à 3",
    duree: "3 séances de 30 min",
  },

  revision: {
    questions: [
      { q: "Quels sont les trois chiffres qui composent un nombre à trois chiffres ?", ra: "Les centaines (C), les dizaines (D) et les unités (U)." },
      { q: "Combien font 10 dizaines ?", ra: "10 dizaines font 1 centaine (100)." },
      { q: "Cite un nombre à deux chiffres et un nombre à trois chiffres.", ra: "Réponse libre, par exemple : 45 (deux chiffres) et 128 (trois chiffres)." },
    ],
  },

  miseEnSituation: {
    histoire: "Au marché de Sabotsy, Vola compte les tomates que sa mère a vendues aujourd'hui : elle a vendu 7 caisses pleines de 100 tomates, 6 tas de 10 tomates, et 4 tomates seules. Vola se demande combien de tomates cela représente au total, et comment écrire ce nombre correctement.",
  },

  presentation: {
    texte: "Aujourd'hui nous allons apprendre : « Les nombres de 0 à 999 ». Après cette séance, vous serez capables de lire, écrire, décomposer, comparer et ranger des nombres de 0 à 999.",
  },

  observation: {
    support: "le tableau de numération affiché au tableau noir, avec les colonnes C, D, U",
    consigne: "Regardez et observez bien ce tableau de numération à trois colonnes : Centaines, Dizaines, Unités.",
  },

  analyse: {
    questions: [
      { q: "Combien de colonnes voyez-vous dans ce tableau ?", ra: "Trois colonnes : Centaines (C), Dizaines (D), Unités (U)." },
      { q: "Dans le nombre 764, quel chiffre est dans la colonne des centaines ?", ra: "Le chiffre 7 est dans la colonne des centaines." },
      { q: "Dans le nombre 602, quel chiffre est dans la colonne des dizaines ?", ra: "Le chiffre 0 est dans la colonne des dizaines : il n'y a aucune dizaine dans ce nombre." },
      { q: "Comment lit-on le nombre 602 à voix haute ?", ra: "On lit « six cent deux » — le zéro des dizaines ne se prononce pas, mais il garde sa place dans le tableau." },
      { q: "Comment lit-on le nombre 573 ?", ra: "On lit « cinq cent soixante-treize »." },
    ],
  },

  synthese: {
    texte: "Donc, un nombre de 0 à 999 s'écrit avec au maximum trois chiffres, placés dans le tableau de numération : Centaines (C), Dizaines (D), Unités (U). Chaque chiffre garde sa place même s'il vaut zéro. Pour lire le nombre, on énonce les centaines, puis le nombre formé par les dizaines et les unités ensemble.",
  },

  numerationExamples: [
    { nombre: 764, c: 7, d: 6, u: 4, lettres: "sept cent soixante-quatre" },
    { nombre: 602, c: 6, d: 0, u: 2, lettres: "six cent deux" },
    { nombre: 573, c: 5, d: 7, u: 3, lettres: "cinq cent soixante-treize" },
    { nombre: 918, c: 9, d: 1, u: 8, lettres: "neuf cent dix-huit" },
    { nombre: 305, c: 3, d: 0, u: 5, lettres: "trois cent cinq" },
  ],

  decompositionExamples: [
    { nombre: 709, decomp: "700 + 9" },
    { nombre: 234, decomp: "200 + 30 + 4" },
    { nombre: 481, decomp: "400 + 80 + 1" },
    { nombre: 350, decomp: "300 + 50" },
  ],

  comparaisonExamples: [
    { a: 764, b: 602, signe: ">", explication: "On compare d'abord les centaines : 7 est plus grand que 6, donc 764 > 602." },
    { a: 573, b: 602, signe: "<", explication: "Les centaines sont différentes : 5 est plus petit que 6, donc 573 < 602." },
    { a: 481, b: 481, signe: "=", explication: "Les centaines, les dizaines et les unités sont identiques, donc 481 = 481." },
  ],

  rangementExample: {
    nombres: [764, 305, 918, 573],
    croissant: "305 < 573 < 764 < 918",
    decroissant: "918 > 764 > 573 > 305",
  },

  applicationExercices: [
    {
      titre: "Exercice 1 — Lecture et écriture",
      consigne: "Écris en lettres les nombres suivants.",
      items: ["a) 256", "b) 840", "c) 703", "d) 999"],
      corrige: ["a) deux cent cinquante-six", "b) huit cent quarante", "c) sept cent trois", "d) neuf cent quatre-vingt-dix-neuf"],
    },
    {
      titre: "Exercice 2 — Décomposition",
      consigne: "Décompose chaque nombre selon ses centaines, dizaines et unités, comme dans l'exemple : 234 = 200 + 30 + 4.",
      items: ["a) 567", "b) 908", "c) 120", "d) 645"],
      corrige: ["a) 567 = 500 + 60 + 7", "b) 908 = 900 + 8", "c) 120 = 100 + 20", "d) 645 = 600 + 40 + 5"],
    },
  ],

  evaluationExercices: [
    {
      titre: "Exercice 1 — Lecture et écriture",
      consigne: "Écris en chiffres les nombres suivants.",
      items: [
        "a) sept cent seize",
        "b) quatre cent deux",
        "c) neuf cent quatre-vingt-douze",
        "d) trois cent soixante-quinze",
      ],
      corrige: ["a) 716", "b) 402", "c) 992", "d) 375"],
    },
    {
      titre: "Exercice 2 — Comparaison et rangement",
      consigne: "Compare les nombres suivants avec le signe qui convient (<, > ou =), puis range-les du plus petit au plus grand.",
      items: [
        "a) 458 ... 584",
        "b) 720 ... 702",
        "c) Range dans l'ordre croissant : 391, 139, 913, 319",
      ],
      corrige: [
        "a) 458 < 584",
        "b) 720 > 702",
        "c) 139 < 319 < 391 < 913",
      ],
    },
  ],

  distracteurs: {
    // pour une future banque QCM/Vrai-Faux : pièges plausibles sur ce sujet précis
    exemples: [
      "Confondre 65 et 75 en lecture rapide (soixante-cinq / soixante-quinze) — piège classique de la tranche 60-79 en français.",
      "Oublier que le zéro au milieu (ex. 602) garde sa place dans le tableau même s'il ne se prononce pas.",
      "Comparer les nombres en regardant le chiffre des unités en premier au lieu des centaines.",
    ],
  },

  attention: "Attention à la lecture des nombres de 60 à 99 : en français, soixante-cinq (65) et soixante-quinze (75) commencent tous les deux par « soixante », mais 65 = 60 + 5 alors que 75 = 60 + 15. De même, attention au zéro placé au milieu d'un nombre (comme dans 602) : il ne s'entend pas à l'oral, mais il faut toujours l'écrire pour garder trois chiffres.",
};
