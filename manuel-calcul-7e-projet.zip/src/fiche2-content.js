// Fiche 2 — Arithmétique — Nombres de 0 à 999 999 (classe Mille + classe Unités)
// Mois 1, 4 séances

module.exports = {
  meta: {
    discipline: "Mathématiques",
    sousDiscipline: "Arithmétique",
    theme: "Les nombres jusqu'au milliard",
    titre: "Les nombres de 0 à 999 999",
    objectif: "Lire, écrire, décomposer, comparer, ranger et résoudre des problèmes avec des nombres de 0 à 999 999",
    documentation: "Programme officiel de Calcul, classe de 7e (page 89)",
    support: "Tableau de numération à deux classes, tableau noir, cahier",
    classe: "7e",
    seance: "4 à 7",
    duree: "4 séances de 30 min",
  },

  revision: {
    questions: [
      { q: "Dans le nombre 764, quel chiffre est le chiffre des centaines ?", ra: "Le chiffre 7." },
      { q: "Range dans l'ordre croissant : 305, 573, 148.", ra: "148 < 305 < 573." },
    ],
  },

  miseEnSituation: {
    histoire: "La commune rurale d'Ambohimanga a compté sa population lors du dernier recensement : 245 380 habitants. Rova n'a jamais vu un nombre aussi grand écrit sur son cahier et se demande comment le lire correctement.",
  },

  presentation: {
    texte: "Aujourd'hui nous allons apprendre : « Les nombres de 0 à 999 999 ». Après cette séance, vous serez capables de lire, écrire, décomposer, comparer et ranger des nombres jusqu'à six chiffres.",
  },

  observation: {
    support: "le tableau de numération à deux classes affiché au tableau noir : la classe des Mille (C-D-U) à gauche, la classe des Unités (C-D-U) à droite",
    consigne: "Regardez et observez bien ce tableau : il a maintenant deux classes de trois colonnes chacune.",
  },

  analyse: {
    questions: [
      { q: "Combien de classes voyez-vous maintenant dans ce tableau ?", ra: "Deux classes : la classe des Mille et la classe des Unités." },
      { q: "Dans le nombre 245 380, quels chiffres forment la classe des Mille ?", ra: "245 forme la classe des Mille." },
      { q: "Comment lit-on 245 380 ?", ra: "On lit « deux cent quarante-cinq mille trois cent quatre-vingts »." },
      { q: "Comment écrit-on 1 000 en lettres ?", ra: "On écrit « mille », jamais « un mille » : le mot mille ne prend jamais « un » devant lui." },
      { q: "Comment lit-on 302 040 ?", ra: "On lit « trois cent deux mille quarante » : le zéro des centaines dans la classe des unités ne se prononce pas, mais il garde sa place." },
    ],
  },

  synthese: {
    texte: "Donc, pour lire un nombre de 0 à 999 999, on le sépare en deux classes de trois chiffres : la classe des Mille (à gauche) et la classe des Unités (à droite), séparées par un espace. On lit chaque classe comme un nombre de 0 à 999, puis on ajoute le mot « mille » après la première classe (sauf si elle vaut 000, on ne dit rien). Le mot « mille » ne change jamais, il ne prend jamais « un » devant lui ni de « s ».",
  },

  numerationExamples: [
    { nombre: "764 502", classeM: "764", classeU: "502", lettres: "sept cent soixante-quatre mille cinq cent deux" },
    { nombre: "100 000", classeM: "100", classeU: "000", lettres: "cent mille" },
    { nombre: "5 000", classeM: "005", classeU: "000", lettres: "cinq mille" },
    { nombre: "302 040", classeM: "302", classeU: "040", lettres: "trois cent deux mille quarante" },
    { nombre: "245 380", classeM: "245", classeU: "380", lettres: "deux cent quarante-cinq mille trois cent quatre-vingts" },
  ],

  decompositionExamples: [
    { nombre: "245 380", decomp: "200 000 + 40 000 + 5 000 + 300 + 80" },
    { nombre: "302 040", decomp: "300 000 + 2 000 + 40" },
    { nombre: "60 705", decomp: "60 000 + 700 + 5" },
  ],

  comparaisonExamples: [
    { a: "764 502", b: "802 304", signe: "<", explication: "On compare d'abord la classe des Mille : 764 est plus petit que 802, donc 764 502 < 802 304." },
    { a: "245 380", b: "245 210", signe: ">", explication: "La classe des Mille est identique (245 = 245), on compare alors la classe des Unités : 380 > 210, donc 245 380 > 245 210." },
  ],

  rangementExample: {
    nombres: ["764 502", "245 380", "802 304", "60 705"],
    croissant: "60 705 < 245 380 < 764 502 < 802 304",
    decroissant: "802 304 > 764 502 > 245 380 > 60 705",
  },

  applicationExercices: [
    {
      titre: "Exercice 1 — Lecture et écriture",
      consigne: "Écris en lettres les nombres suivants.",
      items: ["a) 128 450", "b) 6 000", "c) 500 007"],
      corrige: ["a) cent vingt-huit mille quatre cent cinquante", "b) six mille", "c) cinq cent mille sept"],
    },
    {
      titre: "Exercice 2 — Décomposition",
      consigne: "Décompose chaque nombre selon ses classes et ses chiffres.",
      items: ["a) 356 208", "b) 40 090"],
      corrige: ["a) 356 208 = 300 000 + 50 000 + 6 000 + 200 + 8", "b) 40 090 = 40 000 + 90"],
    },
  ],

  evaluationExercices: [
    {
      titre: "Exercice 1 — Lecture et écriture",
      consigne: "Écris en chiffres les nombres suivants.",
      items: [
        "a) quatre-vingt-treize mille deux cent cinq",
        "b) sept cent mille",
        "c) mille deux",
      ],
      corrige: ["a) 93 205", "b) 700 000", "c) 1 002"],
    },
    {
      titre: "Exercice 2 — Comparaison et rangement",
      consigne: "Compare avec le signe qui convient, puis range dans l'ordre décroissant.",
      items: [
        "a) 128 450 ... 128 045",
        "b) Range dans l'ordre décroissant : 45 200, 452 000, 4 520, 245 000",
      ],
      corrige: [
        "a) 128 450 > 128 045",
        "b) 452 000 > 245 000 > 45 200 > 4 520",
      ],
    },
  ],

  attention: "le mot « mille » ne change jamais : on ne dit jamais « un mille » (on dit simplement « mille ») et il ne prend jamais de « s », même pour plusieurs milliers (ex. « deux cent mille », pas « deux cent milles »). Attention aussi à bien séparer les classes par un espace en écrivant les chiffres : 245 380, et non 245380 ou 245,380.",
};
