// Fiche 5 — Géométrie — Le carré (périmètre et aire)
// Mois 1, 2 séances

module.exports = {
  meta: {
    discipline: "Mathématiques",
    sousDiscipline: "Géométrie",
    theme: "Périmètre et aire des figures planes",
    titre: "Le carré",
    objectif: "Reconnaître un carré, calculer son périmètre et son aire",
    documentation: "Programme officiel de Calcul, classe de 7e",
    support: "Figure du carré, règle graduée, tableau noir",
    classe: "7e",
    seance: "19 à 20",
    duree: "2 séances de 30 min",
  },

  revision: {
    questions: [
      { q: "Combien de côtés a une figure plane comme un rectangle ?", ra: "Quatre côtés." },
      { q: "Qu'est-ce qu'un angle droit ?", ra: "Un angle qui mesure 90°, comme le coin d'une feuille de cahier." },
    ],
  },

  miseEnSituation: {
    histoire: "Hery veut clôturer un terrain carré de 13 mètres de côté pour son potager. Il doit acheter du grillage pour tout le tour, et il veut aussi savoir quelle surface il pourra cultiver.",
  },

  presentation: {
    texte: "Aujourd'hui nous allons apprendre : « Le carré ». Après cette séance, vous serez capables de reconnaître un carré et de calculer son périmètre et son aire.",
  },

  observation: {
    support: "la figure du carré dessinée au tableau, avec la mesure de son côté indiquée",
    consigne: "Regardez et observez bien cette figure : comptez ses côtés et comparez leurs longueurs.",
  },

  analyse: {
    questions: [
      { q: "Combien de côtés a cette figure ?", ra: "Quatre côtés." },
      { q: "Que remarquez-vous en comparant les longueurs des quatre côtés ?", ra: "Les quatre côtés ont exactement la même longueur." },
      { q: "Que remarquez-vous sur les angles du carré ?", ra: "Les quatre angles sont des angles droits (90°)." },
      { q: "Si le côté du terrain d'Hery mesure 13 m, comment calculer la longueur totale du grillage à acheter ?", ra: "Il faut additionner les 4 côtés : 13 + 13 + 13 + 13, soit 13 × 4." },
    ],
  },

  synthese: {
    texte: "Donc, le carré est une figure plane à quatre côtés égaux et quatre angles droits. Pour calculer son périmètre, on additionne ses 4 côtés égaux, ce qui revient à multiplier la longueur d'un côté par 4 : P = c × 4. Pour calculer son aire, on multiplie la longueur du côté par elle-même : A = c × c.",
  },

  figure: { file: "carre.png", label: "c = 13 m" },

  proprietes: [
    "4 côtés de même longueur",
    "4 angles droits (90°)",
  ],

  formules: [
    { nom: "Périmètre", formule: "P = c × 4", justification: "On additionne les 4 côtés égaux : c + c + c + c = c × 4." },
    { nom: "Aire", formule: "A = c × c", justification: "L'aire d'un carré est le produit de la longueur du côté par elle-même, car un carré est un rectangle dont la longueur et la largeur sont égales." },
  ],

  exempleResolu: {
    enonce: "Calcule le périmètre et l'aire d'un carré de côté c = 13 m.",
    etapes: [
      "P = c × 4",
      "P = 13 × 4",
      "P = 52 m",
      "A = c × c",
      "A = 13 × 13",
      "A = 169 m²",
    ],
  },

  applicationExercices: [
    {
      titre: "Exercice 1 — Périmètre",
      consigne: "Calcule le périmètre d'un carré de côté 7 m.",
      items: ["P = ?"],
      corrige: ["a) P = 7 × 4 = 28 m"],
    },
    {
      titre: "Exercice 2 — Aire",
      consigne: "Calcule l'aire d'un carré de côté 7 m.",
      items: ["A = ?"],
      corrige: ["a) A = 7 × 7 = 49 m²"],
    },
  ],

  evaluationExercices: [
    {
      titre: "Exercice 1 — Problème",
      consigne: "Un champ carré a un côté de 21 m. Calcule son périmètre et son aire.",
      items: ["a) Périmètre", "b) Aire"],
      corrige: ["a) P = 21 × 4 = 84 m", "b) A = 21 × 21 = 441 m²"],
    },
    {
      titre: "Exercice 2 — Problème",
      consigne: "Rova veut clôturer un jardin carré de 10 m de côté avec un grillage qui coûte 2 000 ariary le mètre. Quel est le coût total du grillage ?",
      items: ["a) Périmètre du jardin", "b) Coût total"],
      corrige: ["a) P = 10 × 4 = 40 m", "b) Coût = 40 × 2 000 = 80 000 ariary"],
    },
  ],

  attention: "ne pas confondre périmètre (longueur du tour, en mètres) et aire (surface, en mètres carrés) : le périmètre se calcule en additionnant des longueurs, l'aire en multipliant deux longueurs. Le résultat de l'aire s'exprime toujours avec l'unité « au carré » (m²), jamais en mètres simples.",
};
