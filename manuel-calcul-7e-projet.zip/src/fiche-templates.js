const { Packer, PageBreak, ImageRun } = require("docx");
const {
  Document, Paragraph, TextRun, AlignmentType, Table, TableRow, TableCell,
  WidthType, RED, GREEN, BLUE, BLACK, CORRIGE,
  p, pRuns, pHighlight, cell, metaTable, deroulementHeader, sectionRow,
} = require("./builders.js");
const fs = require("fs");

function qraBlock(items, size = 18) {
  return items.map((it) => p(it.q, { size, spacingAfter: 40 }));
}
function raBlock(items, size = 18) {
  return items.map((it) => pRuns([{ text: "R.A. : ", bold: true }, { text: it.ra }], { size, spacingAfter: 60 }));
}
function exoBlockEnseignant(exos, size = 17) {
  const paras = [];
  exos.forEach((ex) => {
    paras.push(p(ex.titre, { bold: true, size, color: BLUE, spacingAfter: 30 }));
    paras.push(p(ex.consigne, { italics: true, size: size - 1, spacingAfter: 25 }));
    ex.items.forEach((it) => paras.push(p(it, { size: size - 1, spacingAfter: 15 })));
  });
  return paras;
}
function corrigeLine(text, size) {
  const m = text.match(/^(\s*[a-z]\)\s*)(.*)$/i);
  if (!m) return pRuns([{ text, bold: true, color: CORRIGE }], { size, spacingAfter: 15 });
  return pRuns([{ text: m[1] }, { text: m[2], bold: true, color: CORRIGE }], { size, spacingAfter: 15 });
}
function exoBlockApprenants(exos, size = 17) {
  const paras = [];
  exos.forEach((ex) => {
    paras.push(p(" ", { size, spacingAfter: 30 }));
    paras.push(p(" ", { size: size - 1, spacingAfter: 25 }));
    ex.corrige.forEach((it) => paras.push(corrigeLine(it, size - 1)));
  });
  return paras;
}

// ---------- Déroulement générique ----------
function buildDeroulement(c, dureeI, dureeII, dureeIII) {
  const rows = [];
  rows.push(...deroulementHeader());

  rows.push(new TableRow({ children: [
    cell([p("I. RÉVISION", { bold: true, size: 18 }), p(dureeI, { size: 16 })], { width: 12 }),
    cell(qraBlock(c.revision.questions), { width: 28 }),
    cell(raBlock(c.revision.questions), { width: 28 }),
    cell([p("Questions/Réponses", { size: 16 }), p("Individuel", { size: 16 })], { width: 12 }),
    cell([p("—", { size: 16 })], { width: 12 }),
    cell([p("")], { width: 8 }),
  ]}));

  rows.push(sectionRow(`II. NOUVELLE LEÇON — ${dureeII}`));

  rows.push(new TableRow({ children: [
    cell([p("1. Mise en situation", { bold: true, size: 17 })], { width: 12 }),
    cell([p(c.miseEnSituation.histoire, { size: 17 })], { width: 28 }),
    cell([p("Les élèves écoutent et répondent à l'oral.", { size: 17, italics: true })], { width: 28 }),
    cell([p("Histoire contextualisée", { size: 16 })], { width: 12 }),
    cell([p("Tableau noir", { size: 16 })], { width: 12 }),
    cell([p("")], { width: 8 }),
  ]}));

  rows.push(new TableRow({ children: [
    cell([p("2. Présentation", { bold: true, size: 17 })], { width: 12 }),
    cell([p(c.presentation.texte, { size: 17 })], { width: 28 }),
    cell([p("Les élèves écoutent.", { size: 17, italics: true })], { width: 28 }),
    cell([p("Exposé oral", { size: 16 })], { width: 12 }),
    cell([p("Tableau noir, cahier", { size: 16 })], { width: 12 }),
    cell([p("")], { width: 8 }),
  ]}));

  rows.push(new TableRow({ children: [
    cell([p("3. Observation", { bold: true, size: 17 })], { width: 12 }),
    cell([p(`Regardez et observez bien ${c.observation.support}.`, { size: 17 })], { width: 28 }),
    cell([p("Les élèves observent silencieusement.", { size: 17, italics: true })], { width: 28 }),
    cell([p("Observation dirigée", { size: 16 })], { width: 12 }),
    cell([p(c.observation.materiel || "Support visuel", { size: 16 })], { width: 12 }),
    cell([p("")], { width: 8 }),
  ]}));

  rows.push(new TableRow({ children: [
    cell([p("4. Analyse", { bold: true, size: 17 })], { width: 12 }),
    cell(qraBlock(c.analyse.questions, 17), { width: 28 }),
    cell(raBlock(c.analyse.questions, 17), { width: 28 }),
    cell([p("Questions dirigées", { size: 16 })], { width: 12 }),
    cell([p(c.observation.materiel || "Support visuel", { size: 16 })], { width: 12 }),
    cell([p("")], { width: 8 }),
  ]}));

  rows.push(new TableRow({ children: [
    cell([p("5. Synthèse", { bold: true, size: 17 })], { width: 12 }),
    cell([p(c.synthese.texte, { size: 17 })], { width: 28 }),
    cell([p("Les élèves écoutent.", { size: 17, italics: true })], { width: 28 }),
    cell([p("Exposé oral", { size: 16 })], { width: 12 }),
    cell([p("Tableau noir", { size: 16 })], { width: 12 }),
    cell([p("")], { width: 8 }),
  ]}));

  rows.push(new TableRow({ children: [
    cell([p("6. Application", { bold: true, size: 17 })], { width: 12 }),
    cell(exoBlockEnseignant(c.applicationExercices), { width: 28 }),
    cell(exoBlockApprenants(c.applicationExercices), { width: 28 }),
    cell([p("Travail individuel", { size: 16 })], { width: 12 }),
    cell([p("Cahier, ardoise", { size: 16 })], { width: 12 }),
    cell([p("")], { width: 8 }),
  ]}));

  rows.push(new TableRow({ children: [
    cell([p("III. ÉVALUATION", { bold: true, size: 18 }), p(dureeIII, { size: 16 })], { width: 12 }),
    cell(exoBlockEnseignant(c.evaluationExercices), { width: 28 }),
    cell(exoBlockApprenants(c.evaluationExercices), { width: 28 }),
    cell([p("Travail individuel", { size: 16 })], { width: 12 }),
    cell([p("Cahier, feuille d'évaluation", { size: 16 })], { width: 12 }),
    cell([p("")], { width: 8 }),
  ]}));

  return new Table({ width: { size: 100, type: WidthType.PERCENTAGE }, rows });
}

// ---------- LEÇON — type numération (fiches 1 à 4) ----------
function tableauCDUDynamic(examples, columns) {
  // columns: [{label, key}, ...] — ex: [{label:"C",key:"c"},{label:"D",key:"d"},{label:"U",key:"u"}]
  // ou [{label:"Mille",key:"classeM"},{label:"Unités",key:"classeU"}]
  const header = new TableRow({ children: [
    cell([p("Nombre", { bold: true, size: 17 })], { shading: "DDEEFF" }),
    ...columns.map((col) => cell([p(col.label, { bold: true, size: 17, align: AlignmentType.CENTER })], { shading: "DDEEFF" })),
    cell([p("En lettres", { bold: true, size: 17 })], { shading: "DDEEFF" }),
  ]});
  const rows = examples.map((ex) => new TableRow({ children: [
    cell([p(ex.nombre !== undefined ? String(ex.nombre) : "", { size: 17, align: AlignmentType.CENTER })]),
    ...columns.map((col) => cell([p(String(ex[col.key] ?? ""), { size: 17, align: AlignmentType.CENTER })])),
    cell([p(ex.lettres, { size: 17 })]),
  ]}));
  return new Table({ width: { size: 100, type: WidthType.PERCENTAGE }, rows: [header, ...rows] });
}

function buildLeconNumeration(c, columns) {
  const paras = [];
  paras.push(p(c.meta.titre, { bold: true, size: 28, color: RED, align: AlignmentType.CENTER, spacingAfter: 240 }));

  paras.push(p(`1. Lecture et écriture des ${c.meta.titre.toLowerCase().replace("les ", "")}`, { bold: true, size: 21, color: GREEN, spacingBefore: 120, spacingAfter: 100 }));
  paras.push(pHighlight(
    `Un nombre s'écrit dans un tableau de numération composé de classes de trois colonnes chacune (Centaines, Dizaines, Unités). Chaque chiffre occupe une place précise selon sa valeur.`,
    "tableau de numération", BLUE, { size: 20, spacingAfter: 120 }
  ));
  paras.push(p("Exemples :", { bold: true, size: 20, spacingAfter: 80 }));
  paras.push(tableauCDUDynamic(c.numerationExamples, columns));

  paras.push(pRuns([
    { text: "Attention : ", bold: true, color: RED },
    { text: c.attention },
  ], { size: 19, spacingBefore: 200, spacingAfter: 200 }));

  paras.push(p("2. Décomposition d'un nombre", { bold: true, size: 21, color: GREEN, spacingAfter: 100 }));
  paras.push(pHighlight(
    "Décomposer un nombre, c'est écrire la valeur de chaque chiffre séparément, selon sa position dans le tableau de numération.",
    "Décomposer", BLUE, { size: 20, spacingAfter: 100 }
  ));
  c.decompositionExamples.forEach((ex) => {
    paras.push(p(`${ex.nombre} = ${ex.decomp}`, { size: 19, spacingAfter: 60, align: AlignmentType.CENTER }));
  });

  paras.push(p("3. Comparaison de deux nombres", { bold: true, size: 21, color: GREEN, spacingBefore: 200, spacingAfter: 100 }));
  paras.push(pHighlight(
    "Pour comparer deux nombres, on compare d'abord le nombre de chiffres, puis classe par classe en partant de la gauche.",
    "comparer", BLUE, { size: 20, spacingAfter: 100 }
  ));
  c.comparaisonExamples.forEach((ex) => {
    paras.push(p(`${ex.a} ${ex.signe} ${ex.b} — ${ex.explication}`, { size: 18, spacingAfter: 60 }));
  });

  paras.push(p("4. Rangement d'une série de nombres", { bold: true, size: 21, color: GREEN, spacingBefore: 200, spacingAfter: 100 }));
  paras.push(pHighlight(
    "Ranger des nombres, c'est les placer dans l'ordre croissant (du plus petit au plus grand) ou décroissant (du plus grand au plus petit).",
    "Ranger", BLUE, { size: 20, spacingAfter: 100 }
  ));
  paras.push(p(`Nombres donnés : ${c.rangementExample.nombres.join(", ")}`, { size: 18, spacingAfter: 60 }));
  paras.push(p(`Ordre croissant : ${c.rangementExample.croissant}`, { size: 18, spacingAfter: 60 }));
  paras.push(p(`Ordre décroissant : ${c.rangementExample.decroissant}`, { size: 18, spacingAfter: 60 }));

  return paras;
}

// ---------- LEÇON — type géométrie (figure + formules) ----------
function buildLeconGeometrie(c) {
  const paras = [];
  paras.push(p(c.meta.titre, { bold: true, size: 28, color: RED, align: AlignmentType.CENTER, spacingAfter: 200 }));

  const imgPath = `./assets/${c.figure.file}`;
  const imgBuffer = fs.readFileSync(imgPath);
  paras.push(new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 100 },
    children: [new ImageRun({ data: imgBuffer, transformation: { width: 280, height: 220 }, type: "png" })],
  }));
  paras.push(p(c.figure.label, { bold: true, size: 19, align: AlignmentType.CENTER, spacingAfter: 240 }));

  paras.push(p("Propriétés", { bold: true, size: 21, color: GREEN, spacingAfter: 100 }));
  c.proprietes.forEach((pr) => paras.push(p(`• ${pr}`, { size: 20, spacingAfter: 60 })));

  paras.push(p("Formules", { bold: true, size: 21, color: GREEN, spacingBefore: 200, spacingAfter: 100 }));
  c.formules.forEach((f) => {
    paras.push(pRuns([{ text: `${f.nom} : `, bold: true }, { text: f.formule, bold: true, color: BLUE }], { size: 20, spacingAfter: 60 }));
    paras.push(p(f.justification, { size: 19, spacingAfter: 120 }));
  });

  paras.push(p("Exemple", { bold: true, size: 21, color: GREEN, spacingBefore: 200, spacingAfter: 100 }));
  paras.push(p(c.exempleResolu.enonce, { italics: true, size: 19, spacingAfter: 100 }));
  c.exempleResolu.etapes.forEach((et) => paras.push(p(et, { size: 20, align: AlignmentType.CENTER, spacingAfter: 50 })));

  paras.push(pRuns([
    { text: "Attention : ", bold: true, color: RED },
    { text: c.attention },
  ], { size: 19, spacingBefore: 240, spacingAfter: 100 }));

  return paras;
}

// ---------- LEÇON — type mesure (tableau de conversion) ----------
function buildLeconMesureConversion(c) {
  const paras = [];
  paras.push(p(c.meta.titre, { bold: true, size: 28, color: RED, align: AlignmentType.CENTER, spacingAfter: 240 }));

  paras.push(p("Le tableau des unités", { bold: true, size: 21, color: GREEN, spacingAfter: 100 }));
  const unites = c.tableauConversion.unites;
  const headerRow = new TableRow({ children: unites.map((u) => cell([p(u, { bold: true, size: 18, align: AlignmentType.CENTER })], { shading: "DDEEFF" })) });
  const exempleRows = c.tableauConversion.exemples.map((ex) => {
    const cells = unites.map((u, i) => {
      const rel = i - ex.colonneDepart;
      const val = rel >= 0 && rel < ex.chiffres.length ? ex.chiffres[rel] : "";
      return cell([p(val, { size: 18, align: AlignmentType.CENTER })]);
    });
    return new TableRow({ children: cells });
  });
  paras.push(new Table({ width: { size: 100, type: WidthType.PERCENTAGE }, rows: [headerRow, ...exempleRows] }));
  paras.push(p("", { spacingAfter: 100 }));
  c.tableauConversion.exemples.forEach((ex) => paras.push(p(ex.valeur, { size: 19, spacingAfter: 60, align: AlignmentType.CENTER })));

  paras.push(p("Règle de conversion", { bold: true, size: 21, color: GREEN, spacingBefore: 200, spacingAfter: 100 }));
  paras.push(pHighlight(c.reglePratique, "virgule", BLUE, { size: 20, spacingAfter: 100 }));

  paras.push(pRuns([
    { text: "Attention : ", bold: true, color: RED },
    { text: c.attention },
  ], { size: 19, spacingBefore: 200, spacingAfter: 100 }));

  return paras;
}

// ---------- LEÇON — type "concept" générique (règle + exemple résolu, sans figure) ----------
function buildLeconConcept(c) {
  const paras = [];
  paras.push(p(c.meta.titre, { bold: true, size: 28, color: RED, align: AlignmentType.CENTER, spacingAfter: 240 }));

  paras.push(p("Règle", { bold: true, size: 21, color: GREEN, spacingAfter: 100 }));
  paras.push(p(c.synthese.texte, { size: 20, spacingAfter: 160 }));

  paras.push(p("Exemple", { bold: true, size: 21, color: GREEN, spacingAfter: 100 }));
  paras.push(p(c.exempleResolu.enonce, { italics: true, size: 19, spacingAfter: 100 }));
  c.exempleResolu.etapes.forEach((et) => paras.push(p(et, { size: 20, spacingAfter: 50 })));

  paras.push(pRuns([
    { text: "Attention : ", bold: true, color: RED },
    { text: c.attention },
  ], { size: 19, spacingBefore: 240, spacingAfter: 100 }));

  return paras;
}

// ---------- EXERCICES (générique, toutes fiches) ----------
function buildExercices(c) {
  const allExos = [...c.applicationExercices, ...c.evaluationExercices];
  const pointsParExo = 5;
  const total = allExos.length * pointsParExo;
  const paras = [];
  paras.push(p("EXERCICES", { bold: true, size: 26, color: RED, align: AlignmentType.CENTER, spacingBefore: 300, spacingAfter: 200 }));
  allExos.forEach((ex) => {
    paras.push(pRuns([
      { text: `${ex.titre} `, bold: true, color: BLUE },
      { text: `(${pointsParExo} points)`, bold: true },
    ], { size: 20, spacingAfter: 60 }));
    paras.push(p(ex.consigne, { italics: true, size: 19, spacingAfter: 60 }));
    ex.items.forEach((it) => paras.push(p(it, { size: 19, spacingAfter: 30 })));
    paras.push(p("Corrigé :", { bold: true, size: 19, spacingBefore: 80, spacingAfter: 40 }));
    ex.corrige.forEach((it) => paras.push(corrigeLine(it, 19)));
    paras.push(p("", { size: 10, spacingAfter: 120 }));
  });
  paras.push(p(`Total : ${total} points`, { bold: true, size: 20, align: AlignmentType.RIGHT, spacingBefore: 100 }));
  return paras;
}

// ---------- Assemble une fiche complète (prep + leçon + exercices) ----------
function assembleFiche(c, opts) {
  const { seanceLabel, totalFiches, dureeI, dureeII, dureeIII, buildLeconBody, first } = opts;
  const children = [];
  if (!first) children.push(new Paragraph({ children: [new PageBreak()] }));
  children.push(p(`SÉANCE ${seanceLabel} / ${totalFiches}`, { bold: true, size: 18, align: AlignmentType.CENTER, spacingAfter: 40 }));
  children.push(p(c.meta.titre, { bold: true, size: 24, align: AlignmentType.CENTER, spacingAfter: 40 }));
  children.push(p("FICHE DE PRÉPARATION", { bold: true, size: 22, align: AlignmentType.CENTER, spacingAfter: 200 }));
  children.push(metaTable(c.meta));
  children.push(p("", { spacingAfter: 100 }));
  children.push(buildDeroulement(c, dureeI, dureeII, dureeIII));

  children.push(new Paragraph({ children: [new PageBreak()] }));
  children.push(p("LEÇON", { bold: true, size: 20, align: AlignmentType.CENTER, spacingAfter: 100 }));
  children.push(...buildLeconBody(c));
  children.push(...buildExercices(c));

  return children;
}

module.exports = {
  Packer, ImageRun,
  buildDeroulement, buildLeconNumeration, buildLeconGeometrie, buildLeconMesureConversion, buildLeconConcept,
  buildExercices, assembleFiche, tableauCDUDynamic,
};
