// Fiche 6 — Géométrie — Le rectangle (périmètre et aire)
// Mois 1, 2 séances

module.exports = {
  meta: {
    discipline: "Mathématiques",
    sousDiscipline: "Géométrie",
    theme: "Périmètre et aire des figures planes",
    titre: "Le rectangle",
    objectif: "Reconnaître un rectangle, calculer son périmètre et son aire",
    documentation: "Programme officiel de Calcul, classe de 7e",
    support: "Figure du rectangle, règle graduée, tableau noir",
    classe: "7e",
    seance: "21 à 22",
    duree: "2 séances de 30 min",
  },

  revision: {
    questions: [
      { q: "Combien de côtés et d'angles droits a un carré ?", ra: "4 côtés égaux et 4 angles droits." },
      { q: "Quelle est la formule du périmètre du carré ?", ra: "P = c × 4." },
    ],
  },

  miseEnSituation: {
    histoire: "Soa possède un terrain rectangulaire de 18 m de longueur sur 9 m de largeur. Elle veut poser une clôture tout autour et connaître la surface disponible pour construire sa maison.",
  },

  presentation: {
    texte: "Aujourd'hui nous allons apprendre : « Le rectangle ». Après cette séance, vous serez capables de reconnaître un rectangle et de calculer son périmètre et son aire.",
  },

  observation: {
    support: "la figure du rectangle dessinée au tableau, avec ses deux dimensions indiquées",
    consigne: "Regardez et observez bien cette figure : comparez la longueur et la largeur.",
  },

  analyse: {
    questions: [
      { q: "Combien de côtés a cette figure ?", ra: "Quatre côtés." },
      { q: "Tous les côtés ont-ils la même longueur, comme dans le carré ?", ra: "Non : deux côtés sont longs (la longueur) et deux côtés sont courts (la largeur), mais les côtés opposés sont égaux." },
      { q: "Que remarquez-vous sur les angles du rectangle ?", ra: "Les quatre angles sont des angles droits (90°), comme dans le carré." },
      { q: "Comment calculer le tour complet du terrain de Soa (18 m sur 9 m) ?", ra: "Il faut additionner les 4 côtés : 18 + 9 + 18 + 9, soit deux fois la somme de la longueur et de la largeur." },
    ],
  },

  synthese: {
    texte: "Donc, le rectangle est une figure plane à quatre côtés et quatre angles droits, avec deux longueurs égales et deux largeurs égales. Pour calculer son périmètre, on additionne les 4 côtés, ce qui revient à faire : P = (L + l) × 2. Pour calculer son aire, on multiplie la longueur par la largeur : A = L × l.",
  },

  figure: { file: "rectangle.png", label: "L = 18 m / l = 9 m" },

  proprietes: [
    "4 côtés : 2 longueurs égales et 2 largeurs égales",
    "4 angles droits (90°)",
  ],

  formules: [
    { nom: "Périmètre", formule: "P = (L + l) × 2", justification: "Le rectangle a deux longueurs et deux largeurs : on additionne L + l, puis on multiplie par 2 car cette somme apparaît deux fois." },
    { nom: "Aire", formule: "A = L × l", justification: "L'aire d'un rectangle est le produit de sa longueur par sa largeur." },
  ],

  exempleResolu: {
    enonce: "Calcule le périmètre et l'aire d'un rectangle de longueur L = 18 m et de largeur l = 9 m.",
    etapes: [
      "P = (L + l) × 2",
      "P = (18 + 9) × 2",
      "P = 27 × 2",
      "P = 54 m",
      "A = L × l",
      "A = 18 × 9",
      "A = 162 m²",
    ],
  },

  applicationExercices: [
    {
      titre: "Exercice 1 — Périmètre",
      consigne: "Calcule le périmètre d'un rectangle de longueur 25 m et de largeur 14 m.",
      items: ["P = ?"],
      corrige: ["a) P = (25 + 14) × 2 = 78 m"],
    },
    {
      titre: "Exercice 2 — Aire",
      consigne: "Calcule l'aire du même rectangle (longueur 25 m, largeur 14 m).",
      items: ["A = ?"],
      corrige: ["a) A = 25 × 14 = 350 m²"],
    },
  ],

  evaluationExercices: [
    {
      titre: "Exercice 1 — Problème",
      consigne: "Un champ rectangulaire mesure 32 m de longueur et 15 m de largeur. Calcule son périmètre et son aire.",
      items: ["a) Périmètre", "b) Aire"],
      corrige: ["a) P = (32 + 15) × 2 = 94 m", "b) A = 32 × 15 = 480 m²"],
    },
    {
      titre: "Exercice 2 — Problème",
      consigne: "Koto veut clôturer un terrain rectangulaire de 40 m de longueur et 20 m de largeur avec un grillage qui coûte 1 500 ariary le mètre. Quel est le coût total ?",
      items: ["a) Périmètre du terrain", "b) Coût total"],
      corrige: ["a) P = (40 + 20) × 2 = 120 m", "b) Coût = 120 × 1 500 = 180 000 ariary"],
    },
  ],

  attention: "ne pas additionner seulement une longueur et une largeur pour le périmètre : il faut bien compter les 4 côtés, donc multiplier la somme (L + l) par 2. Une erreur fréquente est d'oublier ce « × 2 » et de donner un périmètre deux fois trop petit.",
};
