// Fiche 7 — Géométrie — Le triangle (périmètre et aire)
// Mois 1, 2 séances

module.exports = {
  meta: {
    discipline: "Mathématiques",
    sousDiscipline: "Géométrie",
    theme: "Périmètre et aire des figures planes",
    titre: "Le triangle",
    objectif: "Reconnaître un triangle, calculer son périmètre et son aire",
    documentation: "Programme officiel de Calcul, classe de 7e",
    support: "Figure du triangle, règle graduée, tableau noir",
    classe: "7e",
    seance: "23 à 24",
    duree: "2 séances de 30 min",
  },

  revision: {
    questions: [
      { q: "Quelle est la formule de l'aire du rectangle ?", ra: "A = L × l." },
      { q: "Quelle est l'unité de l'aire d'un terrain mesuré en mètres ?", ra: "Le mètre carré (m²)." },
    ],
  },

  miseEnSituation: {
    histoire: "Aina possède un terrain en forme de triangle, hérité de sa grand-mère. La base mesure 12 m, la hauteur 9 m, et le troisième côté (l'hypoténuse) 15 m. Elle veut connaître la longueur totale de la clôture et la surface du terrain.",
  },

  presentation: {
    texte: "Aujourd'hui nous allons apprendre : « Le triangle ». Après cette séance, vous serez capables de reconnaître un triangle et de calculer son périmètre et son aire.",
  },

  observation: {
    support: "la figure du triangle dessinée au tableau, avec sa base, sa hauteur et son troisième côté indiqués",
    consigne: "Regardez et observez bien cette figure : comptez ses côtés et repérez l'angle droit.",
  },

  analyse: {
    questions: [
      { q: "Combien de côtés a un triangle ?", ra: "Trois côtés." },
      { q: "Dans cette figure, quel angle est un angle droit ?", ra: "L'angle entre la base et la hauteur." },
      { q: "Comment calculer le tour complet du terrain d'Aina (12 m, 9 m et 15 m) ?", ra: "Il faut additionner les trois côtés : 12 + 9 + 15." },
      { q: "Pour l'aire, pourquoi divise-t-on le produit base × hauteur par 2 ?", ra: "Parce qu'un triangle rectangle correspond exactement à la moitié d'un rectangle de mêmes base et hauteur." },
    ],
  },

  synthese: {
    texte: "Donc, le triangle est une figure plane à trois côtés. Pour calculer son périmètre, on additionne ses trois côtés : P = a + b + c. Pour calculer son aire, on multiplie la base par la hauteur puis on divise par 2 : A = (b × h) ÷ 2, car le triangle représente la moitié d'un rectangle de mêmes dimensions.",
  },

  figure: { file: "triangle.png", label: "b = 12 m, h = 9 m, hypoténuse = 15 m" },

  proprietes: [
    "3 côtés",
    "Ici, un angle droit entre la base et la hauteur (triangle rectangle)",
  ],

  formules: [
    { nom: "Périmètre", formule: "P = a + b + c", justification: "On additionne simplement les trois côtés du triangle." },
    { nom: "Aire", formule: "A = (b × h) ÷ 2", justification: "Le triangle rectangle est la moitié d'un rectangle de longueur b et de largeur h ; on divise donc le produit b × h par 2." },
  ],

  exempleResolu: {
    enonce: "Calcule le périmètre et l'aire du terrain d'Aina : base b = 12 m, hauteur h = 9 m, troisième côté = 15 m.",
    etapes: [
      "P = 12 + 9 + 15",
      "P = 36 m",
      "A = (b × h) ÷ 2",
      "A = (12 × 9) ÷ 2",
      "A = 108 ÷ 2",
      "A = 54 m²",
    ],
  },

  applicationExercices: [
    {
      titre: "Exercice 1 — Périmètre",
      consigne: "Un triangle a des côtés de 6 m, 8 m et 10 m. Calcule son périmètre.",
      items: ["P = ?"],
      corrige: ["a) P = 6 + 8 + 10 = 24 m"],
    },
    {
      titre: "Exercice 2 — Aire",
      consigne: "Un triangle a une base de 20 m et une hauteur de 15 m. Calcule son aire.",
      items: ["A = ?"],
      corrige: ["a) A = (20 × 15) ÷ 2 = 150 m²"],
    },
  ],

  evaluationExercices: [
    {
      titre: "Exercice 1 — Problème",
      consigne: "Un champ triangulaire a une base de 15 m, une hauteur de 20 m et un troisième côté de 25 m. Calcule son périmètre et son aire.",
      items: ["a) Périmètre", "b) Aire"],
      corrige: ["a) P = 15 + 20 + 25 = 60 m", "b) A = (15 × 20) ÷ 2 = 150 m²"],
    },
    {
      titre: "Exercice 2 — Problème",
      consigne: "Un terrain triangulaire a une base de 6 m et une hauteur de 8 m. Quelle surface représente-t-il en mètres carrés ?",
      items: ["A = ?"],
      corrige: ["a) A = (6 × 8) ÷ 2 = 24 m²"],
    },
  ],

  attention: "ne pas oublier de diviser par 2 dans la formule de l'aire du triangle : c'est l'erreur la plus fréquente, car on calcule alors l'aire d'un rectangle au lieu de celle du triangle (le résultat est deux fois trop grand). Attention aussi à ne pas confondre la hauteur avec le troisième côté du triangle : ce ne sont pas la même mesure.",
};
