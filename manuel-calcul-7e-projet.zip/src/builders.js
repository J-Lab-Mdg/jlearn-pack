const {
  Document, Paragraph, TextRun, AlignmentType,
  Table, TableRow, TableCell, WidthType, BorderStyle,
  ShadingType, VerticalMergeType, VerticalAlign,
} = require("docx");

const RED = "C00000";
const GREEN = "1E7B34";
const BLUE = "1F4E79";
const BLACK = "000000";
const CORRIGE = "E9704F"; // rose saumon (demandé par l'utilisateur, remplace #C2185B)
const HEADER_SHADE = "DDEEFF";
const SUBHEADER_SHADE = "F5F5F5";

function noBorders() {
  const none = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
  return {
    top: none, bottom: none, left: none, right: none,
    insideHorizontal: none, insideVertical: none,
  };
}

function thinBorders() {
  const line = { style: BorderStyle.SINGLE, size: 4, color: "000000" };
  return {
    top: line, bottom: line, left: line, right: line,
    insideHorizontal: line, insideVertical: line,
  };
}

function p(text, opts = {}) {
  const {
    bold = false, italics = false, color = BLACK, size = 20,
    align = AlignmentType.LEFT, spacingAfter = 100, spacingBefore = 0,
  } = opts;
  return new Paragraph({
    alignment: align,
    spacing: { after: spacingAfter, before: spacingBefore },
    children: [new TextRun({ text, bold, italics, color, size, font: "Times New Roman" })],
  });
}

// Paragraphe multi-runs : segments = [{text, bold, color, italics}, ...]
function pRuns(segments, opts = {}) {
  const { align = AlignmentType.LEFT, spacingAfter = 100, spacingBefore = 0, size = 20 } = opts;
  return new Paragraph({
    alignment: align,
    spacing: { after: spacingAfter, before: spacingBefore },
    children: segments.map(s => new TextRun({
      text: s.text, bold: !!s.bold, italics: !!s.italics,
      color: s.color || BLACK, size: s.size || size, font: "Times New Roman",
    })),
  });
}

function pHighlight(text, keyword, keyColor, opts = {}) {
  const { size = 20, spacingAfter = 100 } = opts;
  if (!keyword || !text.toLowerCase().includes(keyword.toLowerCase())) {
    return p(text, { size, spacingAfter });
  }
  const regex = new RegExp(`(${keyword.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`, "gi");
  const parts = text.split(regex);
  const runs = parts.map((part) =>
    part.toLowerCase() === keyword.toLowerCase()
      ? new TextRun({ text: part, bold: true, color: keyColor, size, font: "Times New Roman" })
      : new TextRun({ text: part, size, font: "Times New Roman" })
  );
  return new Paragraph({ spacing: { after: spacingAfter }, children: runs });
}

function cell(children, opts = {}) {
  return new TableCell({
    columnSpan: opts.colSpan || 1,
    rowSpan: opts.rowSpan || 1,
    verticalMerge: opts.vMerge,
    verticalAlign: opts.vAlign || VerticalAlign.CENTER,
    width: opts.width ? { size: opts.width, type: WidthType.PERCENTAGE } : undefined,
    shading: opts.shading ? { fill: opts.shading, type: ShadingType.CLEAR, color: "auto" } : undefined,
    margins: { top: 60, bottom: 60, left: 100, right: 100 },
    children: children.length ? children : [p("")],
  });
}

function metaTable(meta) {
  // meta: { discipline, sousDiscipline, theme, titre, objectif, documentation, support,
  //         date, classe, seance, duree }
  const leftRows = [
    ["Discipline :", meta.discipline],
    ["Sous discipline :", meta.sousDiscipline],
    ["Thème :", meta.theme],
    ["Titre :", meta.titre],
    ["Objectif spécifique :", meta.objectif],
    ["Documentation :", meta.documentation],
    ["Support et matériel :", meta.support],
  ];
  const rightRows = [
    ["Date :", meta.date || "_______________"],
    ["Classe :", meta.classe],
    ["Séance n° :", meta.seance],
    ["Durée :", meta.duree],
  ];
  const maxLen = Math.max(leftRows.length, rightRows.length);
  const rows = [];
  for (let i = 0; i < maxLen; i++) {
    const l = leftRows[i] || ["", ""];
    const r = rightRows[i] || ["", ""];
    rows.push(new TableRow({
      children: [
        cell([p(l[0], { bold: true, size: 20 })], { width: 20 }),
        cell([p(l[1] || "", { size: 20 })], { width: 30 }),
        cell([p(r[0], { bold: true, size: 20 })], { width: 20 }),
        cell([p(r[1] || "", { size: 20 })], { width: 30 }),
      ],
    }));
  }
  return new Table({ width: { size: 100, type: WidthType.PERCENTAGE }, borders: noBorders(), rows });
}

function deroulementHeader() {
  const row1 = new TableRow({ children: [
    cell([p("Étapes et Durée", { bold: true, size: 18 })], { shading: HEADER_SHADE, rowSpan: 2, width: 12 }),
    cell([p("Déroulement de la leçon", { bold: true, size: 18 })], { shading: HEADER_SHADE, colSpan: 2, width: 56 }),
    cell([p("Technique et Stratégie", { bold: true, size: 18 })], { shading: HEADER_SHADE, rowSpan: 2, width: 12 }),
    cell([p("Support et Matériel", { bold: true, size: 18 })], { shading: HEADER_SHADE, rowSpan: 2, width: 12 }),
    cell([p("Observation", { bold: true, size: 18 })], { shading: HEADER_SHADE, rowSpan: 2, width: 8 }),
  ]});
  const row2 = new TableRow({ children: [
    cell([p("")], { shading: SUBHEADER_SHADE, vMerge: VerticalMergeType.CONTINUE, width: 12 }),
    cell([p("Enseignant", { bold: true, size: 18 })], { shading: SUBHEADER_SHADE, width: 28 }),
    cell([p("Apprenants", { bold: true, size: 18 })], { shading: SUBHEADER_SHADE, width: 28 }),
    cell([p("")], { shading: SUBHEADER_SHADE, vMerge: VerticalMergeType.CONTINUE, width: 12 }),
    cell([p("")], { shading: SUBHEADER_SHADE, vMerge: VerticalMergeType.CONTINUE, width: 12 }),
    cell([p("")], { shading: SUBHEADER_SHADE, vMerge: VerticalMergeType.CONTINUE, width: 8 }),
  ]});
  return [row1, row2];
}

// Une ligne du tableau de déroulement
function deroulementRow(etapeDuree, enseignant, apprenants, technique, support, observation, opts = {}) {
  return new TableRow({ children: [
    cell([p(etapeDuree, { bold: true, size: 18 })], { width: 12 }),
    cell(enseignant, { width: 28 }),
    cell(apprenants, { width: 28 }),
    cell(technique, { width: 12 }),
    cell(support, { width: 12 }),
    cell([p("")], { width: 8 }),
  ]});
}

function sectionRow(titre) {
  return new TableRow({ children: [
    cell([p(titre, { bold: true, size: 19, color: BLACK })], { colSpan: 6, shading: "EDEDED" }),
  ]});
}

module.exports = {
  Document, Paragraph, TextRun, AlignmentType, Table, TableRow, TableCell, WidthType,
  RED, GREEN, BLUE, BLACK, CORRIGE, HEADER_SHADE, SUBHEADER_SHADE,
  noBorders, thinBorders, p, pRuns, pHighlight, cell, metaTable,
  deroulementHeader, deroulementRow, sectionRow,
};
