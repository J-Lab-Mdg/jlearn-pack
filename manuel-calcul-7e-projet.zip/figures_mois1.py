"""
Génère les schémas géométriques (dimensions annotées sur la figure) en PNG, via Pillow.
Trait net, fond blanc, texte noir gras pour les cotes.
"""
from PIL import Image, ImageDraw, ImageFont
import os

OUT = "/home/runner/workspace/manuel-calcul-7e/assets"
os.makedirs(OUT, exist_ok=True)
SCALE = 3  # supersampling pour un rendu net

def _font(size=22):
    for path in [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    ]:
        if os.path.exists(path):
            return ImageFont.truetype(path, size * SCALE)
    return ImageFont.load_default()

def _new(w, h):
    img = Image.new("RGB", (w * SCALE, h * SCALE), "white")
    return img, ImageDraw.Draw(img)

def _save(img, filename):
    img = img.resize((img.width // SCALE, img.height // SCALE), Image.LANCZOS)
    img.save(f"{OUT}/{filename}")
    print("généré:", filename)

def carre(label="c = 13 m", filename="carre.png"):
    w, h = 260, 230
    img, d = _new(w, h)
    f = _font()
    x0, y0, size = 45*SCALE, 45*SCALE, 150*SCALE
    d.rectangle([x0, y0, x0+size, y0+size], outline="black", width=3*SCALE)
    d.rectangle([x0, y0+size-14*SCALE, x0+14*SCALE, y0+size], outline="black", width=1*SCALE)
    d.text((x0+size/2, y0-22*SCALE), label, fill="black", font=f, anchor="mm")
    _save(img, filename)

def rectangle(label_L="L = 18 m", label_l="l = 9 m", filename="rectangle.png"):
    w, h = 380, 230
    img, d = _new(w, h)
    f = _font()
    x0, y0, rw, rh = 105*SCALE, 45*SCALE, 220*SCALE, 110*SCALE
    d.rectangle([x0, y0, x0+rw, y0+rh], outline="black", width=3*SCALE)
    d.rectangle([x0, y0+rh-14*SCALE, x0+14*SCALE, y0+rh], outline="black", width=1*SCALE)
    d.text((x0+rw/2, y0-22*SCALE), label_L, fill="black", font=f, anchor="mm")
    d.text((x0-20*SCALE, y0+rh/2), label_l, fill="black", font=f, anchor="rm")
    _save(img, filename)

def triangle(label_b="b = 12 m", label_h="h = 9 m", label_hyp="15 m", filename="triangle.png"):
    w, h = 340, 270
    img, d = _new(w, h)
    f = _font()
    x0, y0 = 110*SCALE, 30*SCALE
    base, hauteur = 180*SCALE, 160*SCALE
    p1 = (x0, y0)
    p2 = (x0+base, y0+hauteur)
    p3 = (x0, y0+hauteur)
    d.polygon([p1, p2, p3], outline="black", width=3*SCALE)
    d.rectangle([x0, y0+hauteur-14*SCALE, x0+14*SCALE, y0+hauteur], outline="black", width=1*SCALE)
    d.text((x0-25*SCALE, y0+hauteur/2), label_h, fill="black", font=f, anchor="rm")
    d.text(((x0+p2[0])/2, y0+hauteur+25*SCALE), label_b, fill="black", font=f, anchor="mm")
    # étiquette hypoténuse au milieu de la diagonale, légèrement décalée
    midx, midy = (p1[0]+p2[0])/2, (p1[1]+p2[1])/2
    d.text((midx+22*SCALE, midy-6*SCALE), label_hyp, fill="black", font=f, anchor="lm")
    _save(img, filename)

if __name__ == "__main__":
    carre()
    rectangle()
    triangle()
