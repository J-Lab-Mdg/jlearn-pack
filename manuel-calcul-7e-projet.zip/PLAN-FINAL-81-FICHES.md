# Plan final validé — 81 fiches — Manuel Mathématiques 7e (V1)

**Statut : VALIDÉ par l'utilisateur, ne pas rouvrir la discussion sur le découpage.**

Règles actées :
- 1 fiche = 1 objectif/technique précis (jamais deux techniques mélangées, ex. Addition et Soustraction = 2 fiches distinctes)
- Calcul Mental n'est PAS une fiche à part : ce sont 5 min intégrées en tout début de chaque séance (avant I. Révision), technique du mois indiquée sous le titre du mois
- Séances vides = pas de total donné dans le programme officiel, à ne pas inventer

**81 fiches total : Arithmétique 32 · Géométrie 19 · Mesure 30 (dont 3 sans total séances)**

---

## TRIMESTRE 1

### Mois 1 — 3 semaines — Calcul mental : ×0,50 et ÷0,50 — ✅ FICHES 1-9 TERMINÉES ET LIVRÉES (Mois1-Complet.docx)
Arithmétique (18) : 1) Nombres 0-999 (3) · 2) 0-999 999 (4) · 3) 0-999 999 999 (5) · 4) 0-999 999 999 999 — classe Milliard (6)
Géométrie (6) : 5) Carré (2) · 6) Rectangle (2) · 7) Triangle (2)
Mesure (6) : 8) Unités de longueur (4) · 9) Échelle sur carte (2)

### Mois 2 — 4 semaines — Calcul mental : ×0,25 et ÷0,25 — ⬜ À FAIRE
Arithmétique (24) : 10) Addition (2) · 11) Soustraction (3) · 12) Multiplication (6) · 13) Division (6) · 14) Divisibilité par 2 (1) · 15) Divisibilité par 5 (2) · 16) Divisibilité par 3 (2) · 17) Divisibilité par 9 (2)
Géométrie (8) : 18) Parallélogramme (2) · 19) Trapèze (2) · 20) Losange (2) · 21) Cercle (2)
Mesure (4) : 22) Unités de capacité (2) · 23) Unités d'aire (2)

### Mois 3 — 2 semaines — Calcul mental : ×0,75 et ÷0,75 — ⬜ À FAIRE
Arithmétique (12) : 24) Présentation/lecture/écriture décimaux (3) · 25) Comparaison/rangement décimaux (3) · 26) Addition décimaux (1) · 27) Soustraction décimaux (2) · 28) Multiplication décimaux (1) · 29) Division décimaux (2)
Géométrie (4) : 30) Aire parallélogramme (1) · 31) Aire trapèze (1) · 32) Aire losange (1) · 33) Aire cercle (1)
Mesure : 34) Problèmes de mesure d'aire — séances non précisées dans le programme (laisser vide)

---

## TRIMESTRE 2

### Mois 4 — 4 semaines — Calcul mental : ×0,25 et ÷0,25 (approfondi) — ⬜ À FAIRE
Arithmétique (24) : 35) Présentation/écriture fraction (4) · 36) Simplification fractions (4) · 37) Comparaison fractions (4) · 38) Addition fractions (2) · 39) Soustraction fractions (2) · 40) Multiplication fractions (2) · 41) Division fractions (2) · 42) Problèmes fractions (4)
Géométrie (8) : 43) Intervalles/piquets circuit ouvert (4) · 44) Intervalles/piquets circuit fermé (4)
Mesure (8) : 45) Unités de volume (4) · 46) Correspondance volume/capacité (4)

### Mois 5 — 3 semaines — Calcul mental : ×0,75 et ÷0,75 (approfondi) — ⬜ À FAIRE
Arithmétique (18) : 47) Notion d'échange, frais, PA/PV (5) · 48) Le bénéfice (2) · 49) La perte (3) · 50) Grandeurs proportionnelles (4) · 51) Problèmes de proportionnalité (4)
Géométrie (6) : 52) Cube (2) · 53) Parallélépipède rectangle (2) · 54) Cylindre (2)
Mesure (6) : 55) Volume approfondi (3) · 56) Problèmes de volume (3)

### Mois 6 — 1 semaine — Calcul mental : ×10, ÷10, ×0,1, ÷0,1 — ⬜ À FAIRE
Arithmétique (6) : 57) Pourcentage et remise (2) · 58) La facture avec taxe (1) · 59) Budget familial (3)
Géométrie (2) : 60) Mesures agraires (2)
Mesure (2) : 61) Nombres sexagésimaux — unités de temps (2)

---

## TRIMESTRE 3

### Mois 7 — 4 semaines — Calcul mental : ×100, ÷100, ×0,01, ÷0,01 (séances non précisées) — ⬜ À FAIRE
Arithmétique (24) : 62) Partages égaux (6) · 63) Partages proportionnels (9) · 64) Partages inégaux (9)
Géométrie (8) : 65) Décomposition figures irrégulières (8)
Mesure (8) : 66) Mouvement uniforme — notion et vitesse (4) · 67) Mouvement uniforme — problèmes (4)

### Mois 8 — 4 semaines — Calcul mental : ×1000, ÷1000, ×0,001, ÷0,001 — ⬜ À FAIRE
Arithmétique (24) : 68) Notion d'épargne (4) · 69) Lieux de placement (4) · 70) Le capital (8) · 71) L'intérêt (8)
Géométrie (8) : 72) Méthode calcul aire polygones irréguliers (4) · 73) Problèmes aire polygones irréguliers (4)
Mesure (8) : 74) Correspondance volume/capacité — séances non précisées (laisser vide) · 75) Vitesse moyenne et unités de vitesse (4)

### Mois 9 — 2 semaines — Calcul mental : révision ×0,001, ÷1000, ÷0,001 — ⬜ À FAIRE
Arithmétique (12) : 76) Durée de placement (6) · 77) Taux de placement (6)
Géométrie (4) : 78) Révision — calcul d'aire polygones irréguliers (4)
Mesure : 79) Correspondance capacité/masse — séances non précisées (laisser vide) · 80) Distance parcourue (1) · 81) Durée de parcours (1)

---

## Gabarit de chaque fiche (validé, ne pas rouvrir)

**FICHE DE PRÉPARATION** : méta-table (Discipline/Sous-discipline/Thème/Titre/Objectif/Documentation/Support | Date/Classe/Séance n°/Durée) + tableau déroulement I. Révision / II. Nouvelle Leçon (1.Mise en situation 2.Présentation 3.Observation 4.Analyse 5.Synthèse 6.Application) / III. Évaluation.

**Mise en situation ≠ question sur le contenu** : toujours une petite histoire contextualisée (prénom malgache, situation concrète), jamais une question qui teste déjà la notion avant qu'elle soit enseignée.

**LEÇON (page à part, après saut de page)** — 3 variantes selon la sous-discipline :
- **Arithmétique (numération)** : titre rouge → tableau de numération rempli d'exemples chiffrés (colonnes dynamiques selon le nombre de classes) → encadré Attention ciblé → Décomposition → Comparaison → Rangement, chaque sous-partie numérotée avec sous-titre vert
- **Géométrie** : titre rouge → schéma (PNG généré via `figures_mois1.py`/Pillow, dimensions annotées sur la figure) → Propriétés → Formules (chacune justifiée, jamais donnée sans explication) → Exemple résolu pas à pas → Attention
- **Mesure** : titre rouge → tableau de conversion avec chiffres insérés dans les colonnes (virgule visible) → Règle de conversion → Attention

**EXERCICES** (après la leçon, pas de saut de page) : barème 5 points/exercice, corrigés vérifiés par calcul réel (jamais estimés), réponse en rose saumon `#E9704F` (mot-clé seulement, pas le "a)").

**Couleurs** : titre rouge `C00000`, sous-titres verts `1E7B34`, mots-clés bleu gras `1F4E79`, corrigé rose saumon `E9704F`.

**Vérifications obligatoires après chaque génération** : `grep -c "<w:sectPr"` = 1, `grep -c "ns0:"` = 0, 0 double espace résiduel (`<w:t>` avec espace double), Times New Roman partout. Conversion PDF de contrôle interne uniquement (jamais livrée à l'utilisateur — il l'a explicitement demandé : "pas de PDF").

## Volumétrie de référence
Mois 1 (9 fiches) = 44 pages → **≈ 4,9 pages/fiche**. Extrapolation sur 81 fiches ≈ **400 pages** pour le manuel complet. L'utilisateur en a été informé et accepte ce volume.
