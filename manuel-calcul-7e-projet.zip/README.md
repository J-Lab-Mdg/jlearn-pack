# README — Manuel Mathématiques 7e — projet Node.js/docx

## Démarrage
```bash
cd manuel-calcul-7e
npm link docx        # PAS npm install : pas d'accès réseau, docx est déjà en cache local sous ce nom
node -e "require('docx')"   # doit afficher aucune erreur
python3 figures_mois1.py    # régénère les 3 PNG géométrie du mois 1 si besoin (assets/)
node src/generate-mois1.js  # régénère le Mois 1 complet (déjà fait, output/Mois1-Complet.docx)
```

## Structure
- `src/builders.js` — fonctions bas niveau réutilisables (paragraphes, tableaux, couleurs, cellules). Ne pas dupliquer, toujours importer d'ici.
- `src/fiche-templates.js` — **fichier central**. Contient :
  - `buildDeroulement()` — tableau I/II/III générique (toute fiche)
  - `buildLeconNumeration(c, columns)` — leçon type Arithmétique/numération (fiches 1-4 et toute future fiche "nombres"). `columns` = liste dynamique de {label, key} selon le nombre de classes du nombre (2 à 4 classes).
  - `buildLeconGeometrie(c)` — leçon type Géométrie (figure PNG + propriétés + formules justifiées + exemple)
  - `buildLeconMesureConversion(c)` — leçon type Mesure avec tableau de conversion (chiffres insérés par colonne)
  - `buildLeconConcept(c)` — leçon générique (règle + exemple résolu, sans figure ni tableau) — utilisée pour "Échelle sur une carte" (fiche 9), réutilisable pour d'autres notions sans figure/tableau
  - `buildExercices(c)` — bloc EXERCICES avec barème (5 pts/exercice) et corrigés en rose saumon
  - `assembleFiche(c, opts)` — assemble une fiche complète (prep + leçon + exercices), gère le saut de page. **Toujours passer `first: true` pour la toute première fiche du document**, sinon page blanche en tête.
- `src/ficheN-content.js` — un fichier par fiche, contenu pur (aucun docx dedans), structure commune à toutes :
  ```js
  { meta, revision, miseEnSituation, presentation, observation, analyse, synthese,
    applicationExercices, evaluationExercices, attention, ...champs spécifiques au type }
  ```
  Champs spécifiques : `numerationExamples/decompositionExamples/comparaisonExamples/rangementExample` (numération) · `figure/proprietes/formules/exempleResolu` (géométrie) · `tableauConversion/reglePratique` (mesure) · `exempleResolu` seul (concept générique).
- `src/generate-moisN.js` — script d'assemblage d'un mois (importe les fiches du mois, appelle `assembleFiche` pour chacune avec la bonne fonction `buildLeconBody`, exporte le docx). **Un script par mois**, à créer pour chaque nouveau mois (copier `generate-mois1.js` et adapter).
- `figures_mois1.py` — générateur de figures géométriques en PNG via Pillow (PAS de SVG→PNG possible ici : pas d'accès réseau pour installer rsvg/cairosvg/imagemagick-delegate). Un fichier par mois à créer si besoin (`figures_moisN.py`), en copiant le pattern (`_new`, `_font`, `_save`, SCALE=3 pour le supersampling).
- `PLAN-FINAL-81-FICHES.md` — **le plan validé, ne pas rouvrir la discussion dessus.** Contient aussi le gabarit détaillé de chaque type de fiche.
- `output/Mois1-Complet.docx` — livrable déjà généré et vérifié (fiches 1 à 9).

## Points de vigilance déjà réglés (ne pas re-découvrir à la dure)
1. `npm install` échoue (403, pas de réseau) → toujours `npm link docx`.
2. Pas d'outil SVG→PNG disponible → dessiner directement avec Pillow (`figures_mois1.py`), export PNG 300dpi via supersampling ×3.
3. `deroulementHeader()` dans `builders.js` a besoin de largeurs de colonnes explicites sur CHAQUE cellule (header ET corps), sinon désalignement visuel entre les deux lignes d'en-tête et le corps du tableau.
4. Le corrigé doit être coloré uniquement sur la réponse elle-même (pas le "a)"), voir fonction `corrigeLine()` dans `fiche-templates.js`.
5. `assembleFiche()` insère un saut de page AVANT chaque fiche — sauf la première (`first: true`), sinon page blanche en tête de document.
6. Vérifications obligatoires après CHAQUE génération (voir `PLAN-FINAL-81-FICHES.md` section vérifications) : sectPr=1, ns0=0, 0 double espace, contrôle visuel en PDF interne (jamais livré à l'utilisateur, il l'a explicitement refusé).
7. Tous les corrigés doivent être vérifiés par calcul réel (bash/python), jamais par estimation — voir les blocs de vérification numérique dans l'historique de la conversation, à reproduire pour chaque nouvelle fiche.
