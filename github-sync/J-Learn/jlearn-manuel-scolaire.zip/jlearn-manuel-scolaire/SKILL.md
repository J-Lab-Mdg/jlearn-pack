---
name: jlearn-manuel-scolaire
description: Création et traitement des manuels scolaires de la Collection J-Learn (Madagascar). Rédige un manuel complet (couverture, avant-propos, séances avec fiche de préparation + leçon + exercices + corrigés, annexes) à partir d'un programme scolaire, ou enrichit/corrige un manuel .docx existant. Utiliser quand l'utilisateur parle d'un manuel J-Learn, d'une fiche de préparation, d'un enrichissement de séances, d'une création de manuel à partir d'un programme, ou envoie un fichier Manuel_*.docx (ou un programme scolaire officiel).
---

# Collection J-Learn — Manuels Scolaires Madagascar

## ⚠️ Règles critiques — à ne JAMAIS enfreindre

Ces règles priment sur tout le reste du skill. Les relire avant toute production ou modification :

1. **Ne jamais commencer** à rédiger ou modifier quoi que ce soit avant le feu vert explicite de l'utilisateur (voir Étape 0).
2. **Matière EPS** et **niveau préscolaire** : ne rien produire, ne rien modifier. Laisser le `.docx` tel quel.
3. **Logo / en-tête institutionnel** : ne jamais toucher — l'utilisateur l'insère lui-même.
4. **`<w:sectPr>`** (propriétés de page) : ne jamais le supprimer ni le dupliquer — exactement 1 par document.
5. **Namespaces `<w:document>`** : ne jamais réécrire cette balise — la conserver intacte depuis un fichier source J-Learn (32 namespaces attendus, 0 `ns0:`).
6. **Contenu des séances d'évaluation** : ignorées entièrement, jamais enrichies.
7. **Toujours garder une copie non modifiée du fichier source** avant toute transformation (voir [`technical-notes.md`](technical-notes.md)).
8. **Rédiger du contenu réel, jamais des méta-instructions.** Voir section "Règle de rédaction" ci-dessous — c'est la faute la plus fréquente.

---

## Contexte

Programme : **Collection J-Learn** — Madagascar (RAPS).
Niveaux couverts : préscolaire, primaire, collège, lycée — **toutes matières**.
Format des fichiers : `.docx` uniquement.

Le skill couvre deux types de tâches, qui ne s'excluent pas :
- **Traitement A — Fiche de préparation** : enrichissement pédagogique + correction du design d'une fiche de préparation (par séance).
- **Traitement B — Manuel complet** : rédaction d'un manuel entier (couverture, avant-propos, table des matières, séances complètes, annexes) — soit à partir d'un manuel existant à compléter, soit à partir de zéro à partir d'un programme scolaire.

Un manuel J-Learn complet = plusieurs séances, chacune composée de **fiche de préparation + contenu de leçon + exercices notés + corrigé**. Structure détaillée : [`manuel-structure.md`](manuel-structure.md).

---

## Étape 0 — Collecte d'informations avant de commencer

**Toujours poser ces questions au début, dans cet ordre :**

1. **Quel niveau et quelle matière ?** (ex : Français 4e, Maths 6e…)
2. **Point de départ — deux cas possibles :**
   - **Cas A : fichier existant à améliorer** → demander de joindre le `.docx` source.
   - **Cas B : création à partir de zéro** → demander le programme scolaire officiel (document RAPS ou équivalent). Si l'utilisateur ne l'a pas, demander **au cas par cas selon la matière** si une recherche de contenu complémentaire sur internet est autorisée (certaines matières ont des programmes très normés où il ne faut rien inventer, d'autres tolèrent des compléments).
3. **Quelle est la portée de la tâche ?**
   - Uniquement les fiches de préparation (Traitement A) ?
   - Le manuel complet avec leçon, exercices et corrigés (Traitement B) ?
4. **Un document de programme officiel est-il disponible ?** (même en Cas A, utile pour connaître la structure des séances : nombre, numérotation, séances d'évaluation à ignorer).
5. **Version malgache incluse ?** Question binaire explicite : *"Le livrable doit-il inclure une version malgache en plus de la version française ? (oui/non)"* — ne pas se contenter d'un "parfois".
6. **Annexes à inclure ?** Demander **matière par matière** lesquelles s'appliquent (ex : les tableaux de conjugaison n'ont pas de sens en Maths ou en SVT). Liste des annexes possibles dans [`manuel-structure.md`](manuel-structure.md) section 7.
7. **Quelle version de livrable ?** Pour nommer le fichier de travail (V1, V2, V3…).
8. **Le manuel doit-il afficher des mois/dates précis, ou rester générique pour un usage pluriannuel ?** Si générique : les pages de séparation de période affichent seulement "Séances X à Y" (sans "1er mois" ni dates calendaires), et l'avant-propos ou le mode d'emploi précise que le calendrier est libre pour l'établissement. Voir [`manuel-structure.md`](manuel-structure.md) section 6.

**⚠️ Ne jamais commencer à rédiger ou modifier quoi que ce soit avant d'avoir le feu vert explicite de l'utilisateur sur ces points.**

---

## Exceptions — ne rien modifier

| Cas | Traitement |
|-----|-----------|
| Matière **EPS** | Laisser le `.docx` tel quel — pas d'enrichissement, pas de fiche, pas de manuel |
| Niveau **préscolaire** | Laisser le `.docx` tel quel — pas d'enrichissement, pas de fiche, pas de manuel |
| Logo / en-tête institutionnel | Ne jamais toucher — l'utilisateur l'insère lui-même |

---

## Structure d'une séance dans le docx source

Chaque séance (S1, S2… selon la numérotation du niveau) contient :
1. Un titre **FICHE DE PRÉPARATION** (ou **TAKELA-PANOMANAN-DESONA** en malgache)
2. Une **méta-table** (informations générales : discipline, thème, durée, classe…)
3. Une **table de déroulement** avec les activités de la leçon
4. *(Traitement B uniquement)* Le **contenu de la leçon** à copier au tableau/cahier, des **exercices notés**, et leur **corrigé**

**Séances d'évaluation** : certaines séances sont des séances d'évaluation (pas de fiche de préparation à enrichir, pas de leçon). Exemples connus : en 3e et 2nde → S4, S9, S14, S19, S24. La liste exacte figure dans le document de programme officiel, ou se repère dans le `.docx` source par le titre ou le contenu de la séance. Ces séances sont **ignorées** pour l'enrichissement mais reçoivent leur propre sujet d'évaluation + corrigé si Traitement B.

---

## Règle de rédaction — contenu réel, jamais des méta-instructions

**Erreur à éviter absolument** : décrire ce qu'il faut faire au lieu de le faire.

| ❌ Incorrect (méta-instruction) | ✅ Correct (contenu réel rédigé) |
|--------------------------------|-----------------------------------|
| "L'enseignant pose des questions sur la dernière leçon." | *« Quelles langues parle-t-on à Madagascar ? » « Connaissez-vous des mots français ? Lesquels ? »* |
| "L'enseignant donne un exercice relatif au thème." | *1. Citez trois villes de Madagascar. 2. Reliez chaque mot à sa définition. 3. Vrai ou faux : …* |
| "Pour les maths : donner un exercice de calcul." | *Calculez : 12 × 7 + 15 =. Effectuez la division suivante : 144 ÷ 12.* |
| "Question orale sur le thème étudié." | *"Que voyez-vous sur cette image ? Comment appelle-t-on cette partie du corps ?"* |

Cette règle s'applique à **toutes les cellules Enseignant/Apprenants de la table de déroulement**, ainsi qu'au **contenu de la leçon** et aux **exercices** en Traitement B. Le contenu doit être immédiatement utilisable par l'enseignant en classe, sans qu'il ait à l'inventer lui-même.

Contexte à intégrer : exemples et prénoms malgaches (ex : Rova, Nivo, Soa, Koto, Hery, Aina, Fara, Lanto, Tiana, Mamy), références géographiques/culturelles malgaches, conformité au programme RAPS.

Le rôle pédagogique de chaque sous-étape (pour guider la rédaction) reste dans [`design-fiche.md`](design-fiche.md) section 6.

### Remplacement "BEPC"

Dans tout le document, remplacer les occurrences de "BEPC" par **"Sujet d'examen [niveau]"**.
Exemples : "Sujet d'examen 3ème", "Sujet d'examen 4ème", "Sujet BAC" pour le lycée.

---

## Traitement A — Fiche de préparation (enrichissement + design)

À faire pour toutes les matières **sauf EPS** et **sauf préscolaire**.

### Sections à enrichir dans chaque séance

| Section | Contenu à produire |
|---------|-------------------|
| **2.5 Synthèse** | Contenu réel de la synthèse (ce que l'enseignant dit après l'analyse, ce que les apprenants copient) |
| **2.6 Application** | Exercice de consolidation rédigé intégralement — énoncé + corrigé dans le même fichier |

Le rôle pédagogique détaillé de chaque étape est dans [`design-fiche.md`](design-fiche.md) section 6.

### Design de la fiche — résumé des corrections

Spécifications complètes dans [`design-fiche.md`](design-fiche.md).

| Élément | Incorrect | Correct |
|---------|----------|---------|
| Position du titre | Après la méta-table | **Avant** la méta-table |
| Police du titre | Calibri ou autre | **Times New Roman, gras, centré, 12pt** |
| Colonnes table déroulement | 5 ou autre | **6 colonnes** (voir structure officielle ci-dessous) |
| En-tête table | 1 ligne | **2 lignes** avec "Déroulement de la leçon" fusionné |
| Séparation des phases | Aucune | **3 lignes grises** (RÉVISION / NOUVELLE LEÇON / ÉVALUATION) |

### Structure officielle 6 colonnes

```
Étapes et Durée | Enseignant | Apprenants | Technique et Stratégie | Support et matériel | Observation
```

(Étapes et Durée = UNE seule colonne fusionnée, pas deux séparées)

Traduction malgache : voir [`vocabulaire-bilingue.md`](vocabulaire-bilingue.md).

### Les 3 phases (ordre toujours identique, numérotation par défaut)

**Par défaut, utiliser la numérotation `1. / 2.1–2.6 / 3.`** (celle documentée ici et dans `design-fiche.md`), sauf si le fichier source à améliorer utilise déjà une autre numérotation (ex : `I. / IIa–IIf / III.`) — dans ce cas, **conserver la numérotation du fichier source** pour ne pas casser la cohérence du document existant.

| N° | Français | Malgache |
|----|---------|---------|
| 1 | 1. RÉVISION — … min | 1. FAMERENANA — … minitra |
| 2 | 2. NOUVELLE LEÇON — … min | 2. LESONA VAOVAO / NOUVELLE LEÇON — … minitra |
| 3 | 3. Évaluation / … min | 3. TOMBANA / … minitra |

Les durées (…) sont extraites du contenu de chaque séance dans le docx source, ou déterminées selon la durée totale de la séance (typiquement 120 min pour une séance standard, à répartir entre les étapes).

---

## Traitement B — Manuel complet

À faire uniquement si l'utilisateur a validé cette portée à l'Étape 0.

Structure complète du manuel (couverture, avant-propos, mode d'emploi, table des matières par thèmes, tableaux de bord par période, contenu de leçon, exercices notés, corrigés, annexes) : voir [`manuel-structure.md`](manuel-structure.md).

Chaque séance en Traitement B contient, dans l'ordre :
1. Fiche de préparation (Traitement A)
2. Contenu de la leçon à copier dans le cahier
3. Exercices notés sur barème
4. Corrigé complet avec barème

---

## Version malgache

Quand une version malgache est demandée (réponse "oui" à la question de l'Étape 0) :
- Titre du document : **TAKELA-PANOMANAN-DESONA**
- Tous les intitulés de la méta-table, colonnes, phases, sous-étapes, et — en Traitement B — de l'avant-propos, du mode d'emploi et des annexes sont traduits
- Tableau de correspondances complet : [`vocabulaire-bilingue.md`](vocabulaire-bilingue.md)

---

## Nommage des fichiers

**Fichiers de travail intermédiaires** (jamais montrés comme livrable final) :
```
Manuel_[Matière]_[Niveau]_V[N]_[ETAPE].docx
```
`ETAPE` = `AMELIORE` (enrichissement), `DESIGN` (design corrigé), `COMPLET` (manuel entier assemblé).

**Livrable final présenté à l'utilisateur** — nom propre, sans suffixe technique :
```
[Matière] [Niveau] - Fiche de préparation - [leçon] - sujet et corrigé.docx
```
ou pour un manuel complet :
```
Manuel de [Matière] - Classe de [Niveau].docx
```

---

## Vérifications obligatoires après génération

Afficher ces compteurs à l'utilisateur après chaque production :

| Vérification | Valeur attendue | Action si échec |
|-------------|----------------|---------|
| `<w:sectPr>` (mise en page) | Exactement **1** | Revenir à la copie de sauvegarde, ne pas livrer le fichier |
| Namespace `ns0` | **0** | Revenir à la copie de sauvegarde, ne pas livrer le fichier |
| Titres "FICHE DE PRÉPARATION" | = nb de séances traitées (± 1 pour avant-propos) | Vérifier les séances manquées, ne pas livrer tant que non résolu |
| Lignes grises "NOUVELLE LEÇON" | = nb de séances traitées | Vérifier les séances manquées |
| Occurrences "Times New Roman" | > 0 | Police non appliquée — corriger avant livraison |
| Colonnes gridCol | 6 par table de déroulement | Structure incorrecte — corriger avant livraison |
| Styles Heading 1 (périodes) / Heading 2 (séances) | = nb de périodes / nb de séances | Titres non navigables dans Word — corriger avant livraison |
| Bordures (`tblBorders`) sur la table de déroulement | Présentes sur cette table uniquement | Traits invisibles — corriger avant livraison (voir [`design-fiche.md`](design-fiche.md) section 3) |

### Procédure d'échec

Si une vérification échoue après **2 tentatives de correction** :
1. Arrêter — ne jamais livrer un fichier qui échoue une vérification.
2. Présenter à l'utilisateur le fichier source original intact (copie de sauvegarde) plutôt qu'un fichier potentiellement corrompu.
3. Expliquer clairement le blocage rencontré (quelle vérification échoue, sur quelle(s) séance(s)) et demander comment procéder.

---

## Approche technique (interne)

Voir [`technical-notes.md`](technical-notes.md) pour les détails Node.js / adm-zip / règles XML / sauvegarde.

---

## Livrable final

- Un fichier `.docx` versionné téléchargeable via `presentAsset`
- Un résumé des modifications et les compteurs de vérification affichés dans le chat
