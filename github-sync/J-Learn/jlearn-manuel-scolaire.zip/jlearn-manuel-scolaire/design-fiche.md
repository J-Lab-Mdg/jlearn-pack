# Design de la Fiche de Préparation — Spécifications complètes

**Rappel de rédaction (voir SKILL.md) : tout le contenu produit dans les cellules Enseignant/Apprenants ci-dessous doit être du contenu réel rédigé (questions exactes, réponses attendues exactes, énoncé d'exercice complet) — jamais une description de ce qu'il faut faire.**

Basé sur les fichiers officiels J-Learn :
- `J-Learn_MODÈLE_FICHE_DE_PRÉPARATION_fr_*.docx` (modèle français)
- `J-Learn_MODÈLE_FICHE_DE_PRÉPARATION__*.docx` (modèle français avec explications bilingues)
- `J-Learn_TAKELA-PANOMANAN-DESONA_modely_*.docx` (modèle malgache)
- `J-Learn_FICHE_DE_PRÉPARATION_-_fillable_*.docx` (version fillable française)
- `J-Learn_TAKELA-PANOMANAN-DESONA_Azo_fenoina_*.docx` (version fillable malgache)
- Capture d'écran du modèle officiel (fournie par l'utilisateur)

---

## 1. Titre du document

| Langue | Titre |
|--------|-------|
| Français | **FICHE DE PRÉPARATION** |
| Malgache | **TAKELA-PANOMANAN-DESONA** |

- **Position** : AVANT la méta-table (au-dessus)
- **Police** : Times New Roman, gras, centré, 12pt

---

## 2. Méta-table (informations générales)

Tableau en haut de la fiche, **après le titre**, contenant les informations de la séance.

### Colonnes (2 zones côte à côte)

**Zone gauche :**
| Français | Malgache | Description |
|---------|---------|-------------|
| Discipline : | Taranja : | Ex : Géographie, Français, SVT… |
| Sous discipline : | Zana-taranja : | Ex : expression écrite, vocabulaire… |
| Thème : | Lohahevitra : | Ex : La ville, L'humain… |
| Titre : | Lohateny : | Ex : Les termes relatifs à la ville… |
| Objectif spécifique : | Tanjona manokana : | Ex : Énumérer les termes relatifs à la ville… |
| Documentation : | Fanovozan-kevitra : | Ex : Manuel FR 7e p. … |
| Support et matériel : ( | Fitaovana : ( | Ex : Image, objet concret, texte… |

**Zone droite :**
| Français | Malgache | Description |
|---------|---------|-------------|
| Date : _______ | Daty : _______ | |
| Classe : | Kilasy : | |
| Séance n° : | Seho n° : | |
| Durée : … min | Faharetany : … minitra | |

---

## 3. Table de déroulement — Structure 6 colonnes

### Colonnes officielles (dans l'ordre)

| N° | Français | Malgache | Notes |
|----|---------|---------|-------|
| 1 | **Étapes et Durée** | **Dingana sy Faharetany** | Colonne unique (Étapes + Durée fusionnés) |
| 2 | **Enseignant** | **Mpampianatra** | Sous "Déroulement de la leçon" |
| 3 | **Apprenants** | **Mpianatra** | Sous "Déroulement de la leçon" |
| 4 | **Technique et Stratégie** | **Tetika Amam-paika** | |
| 5 | **Support et matériel** | **Fitaovana** | |
| 6 | **Observation** | **Fanamarihana** | |

**⚠️ Important** : "Étapes et Durée" est UNE seule colonne fusionnée — pas deux colonnes séparées.

**⚠️ Bordures obligatoires** : cette table doit avoir des traits visibles (fines lignes noires) sur toutes les bordures et lignes intérieures. C'est la seule table du manuel qui doit être bordée — les autres (méta-table, tableau de bord de période, table des matières, annexes) restent sans traits. En python-docx : appliquer manuellement `w:tblBorders` (single, sz=4, color=000000) via OxmlElement, car le tableau créé par `doc.add_table()` n'a pas de bordures par défaut. En XML brut, vérifier que `<w:tblBorders>` est bien présent dans le `<w:tblPr>`.

### En-tête de la table — 2 lignes obligatoires

**Ligne 1 :**
| Col 1 | Col 2-3 (fusionnées) | Col 4 | Col 5 | Col 6 |
|-------|---------------------|-------|-------|-------|
| Étapes et Durée (rowspan 2) | **Déroulement de la leçon** (colspan 2) | Technique et Stratégie (rowspan 2) | Support et matériel (rowspan 2) | Observation (rowspan 2) |

**Ligne 2 :**
| — (vMerge) | Enseignant | Apprenants | — (vMerge) | — (vMerge) | — (vMerge) |

---

## 4. Les 3 phases (lignes grises séparatrices)

Chaque phase commence par une ligne grise fusionnée sur les 6 colonnes :

| N° | Français | Malgache |
|----|---------|---------|
| 1 | **1. RÉVISION — … min** | **1. FAMERENANA — … minitra** |
| 2 | **2. NOUVELLE LEÇON — … min** | **2. LESONA VAOVAO / NOUVELLE LEÇON — … minitra** |
| 3 | **3. Évaluation / … min** | **3. TOMBANA / … minitra** |

- Couleur de fond : gris clair (`D9D9D9`)
- Texte en gras, fusionné sur 6 colonnes (`gridSpan=6`)
- Les durées (…) sont extraites du contenu du docx source

---

## 5. Lignes de contenu par phase

### Phase 1 — RÉVISION

| Colonne | Contenu type |
|---------|-------------|
| Étapes et Durée | **RÉVISION** / … min |
| Enseignant | Posez des questions ou faites réciter oralement… |
| Apprenants | Répondent. R.A. (Réponse Attendue) : … |
| Technique | Question réponse / travail individuel |
| Support | [pas obligatoire à chaque étape] |
| Observation | [pas obligatoire, seulement si élément particulier] |

### Phase 2 — NOUVELLE LEÇON (6 sous-étapes)

| Sous-étape | FR | MG | Rôle pédagogique |
|------------|----|----|-----------------|
| 2.1 | Mise en Situation | Fitarihan-tsaina | Question ou courte histoire avant la nouvelle leçon |
| 2.2 | Présentation | Fanolorana | Annonce du titre et de l'objectif |
| 2.3 | Observation | Fandinihana | Regarder image, texte, objet |
| 2.4 | Analyse | Famakafakana | Questions pour dégager le contenu de la leçon |
| 2.5 | Synthèse | Fandravonana | Récapitulation / règle / principe |
| 2.6 | Application | Fampiharana | Exercice de consolidation |

### Phase 3 — ÉVALUATION

| Colonne | Contenu type |
|---------|-------------|
| Étapes et Durée | **Évaluation** / 5 min |
| Enseignant | Questions orales ou exercices écrits |
| Apprenants | Répondent. (travail individuel) |
| Technique | travail individuel |
| Support | [selon besoin] |
| Observation | [selon besoin] |

---

## 6. Contenu pédagogique détaillé des sous-étapes (à enrichir en 2.5 et 2.6)

### 2.5 Synthèse — Consignes pour l'enseignant
> L'enseignant donne la synthèse des réponses attendues fournies par les apprenants lors de l'analyse.
> Il peut s'agir d'une récapitulation, d'une règle mathématique ou d'un principe.
> Copier dans le cahier.

**Apprenants** : Écoutent / Copient dans leur cahier.  
**Technique** : Travail collectif.

### 2.6 Application — Consignes pour l'enseignant
> Travail de consolidation de ce qui a été acquis.
> Les apprenants appliquent les connaissances de l'analyse (répétition, exercice, règle…).
> Privilégier le travail en groupe / binôme / trinôme.

**Apprenants** : Répètent / Écrivent / Montrent / Font l'exercice.  
**Technique** : Par binôme ou trinôme / par groupe.

---

## 7. Ce qu'il ne faut PAS modifier

- La mise en page globale du document (marges, orientation, taille de page)
- Le `<w:sectPr>` (propriétés de section/page) — ne jamais le supprimer ni le dupliquer
- Le logo ou l'en-tête institutionnel — l'utilisateur l'insère lui-même
- Le contenu des séances d'évaluation (on les saute entièrement)
- Les namespaces de la balise `<w:document>` (32 namespaces attendus)
