# Structure du manuel complet — Traitement B

Basé sur `Manuel_Francais_6e_JLearn_Ameliore.docx` (référence officielle).
Un manuel J-Learn n'est PAS une simple suite de fiches de préparation : c'est un livre pédagogique complet.

---

## 1. Couverture

- Checklist visuelle des composants du manuel :
  ```
  ✓ Fiche de préparation
  ✓ Leçon
  ✓ Exercices
  ✓ Sujets et Corrigés
  ```
- Titre : **MANUEL DE [MATIÈRE]** / **CLASSE DE [NIVEAU]**

---

## 2. Page de titre / métadonnées

| Champ | Exemple |
|-------|---------|
| Auteur | Les développeurs de J-Learn |
| Éditeur | J-Lab |
| Année d'édition | Année scolaire en cours (ex : 2025-2026) |
| Programme | Conforme au programme scolaire (RAPS) |
| Niveau | Classe de [Niveau] |
| Contact | Fourni par l'utilisateur, ne pas inventer |
| Copyright | © J-Lab — Tous droits réservés. Reproduction autorisée à des fins pédagogiques non commerciales. |

Ne jamais inventer d'adresse email ou d'information de contact — demander à l'utilisateur si nécessaire.

---

## 3. Avant-propos

Texte de présentation du manuel, à rédiger sur mesure. Doit couvrir :
- Contexte : équipe J-Lab, Collection J-Learn, plateforme pédagogique numérique
- Conformité au programme (RAPS) de l'année en cours, ministère concerné
- Nombre total de séances et thèmes couverts par le manuel
- Description de ce que contient chaque séance (fiche de préparation détaillée, contenu de leçon, exercices notés, corrigé avec barème)
- Ancrage culturel malgache (noms, contexte, exemples)
- Liste des annexes incluses (voir section 7 — uniquement celles validées avec l'utilisateur)
- Remerciement aux enseignants

---

## 4. Mode d'emploi ("Comment utiliser ce manuel")

Structure en 4 parties, à adapter selon la matière :

**A. La fiche de préparation** (numérotée n° X/Total)
- Explique les champs de la méta-table et les colonnes de la table de déroulement
- Explique les étapes de la séance (numérotation — voir SKILL.md)
- Un conseil pratique pour l'enseignant (ex : "Lisez la fiche ENTIÈREMENT avant le cours. Adaptez les durées à votre classe.")

**B. Le contenu de la leçon** (à copier dans le cahier des élèves)
- Quand le dicter/l'écrire (typiquement à l'étape Synthèse)
- Conventions typographiques (voir section 5)
- Un conseil pratique (ex : "Dictez le contenu en expliquant. Ne dictez jamais sans expliquer.")

**C. Les exercices et la correction**
- Nombre d'exercices, barème (répartition des points)
- Où se trouve la correction (immédiatement après les exercices)
- Un conseil pratique (ex : "Corrigez collectivement en classe après que tous les élèves ont fini.")

**D. Navigation dans le document**
- Numérotation des séances, saut de page entre séances
- Pages de séparation par période/thème (voir section 6)

---

## 5. Contenu de la leçon — conventions typographiques

Le contenu à copier au tableau/cahier suit des conventions de couleur cohérentes dans tout le manuel :

| Niveau | Couleur | Exemple |
|--------|---------|---------|
| Titres (1., 2.) | ROUGE | Grandes parties du cours |
| Sous-titres (A., B.) | VERT | Parties secondaires |
| Sous-sous-titres (1., 2.) | BLEU | Points de détail |
| Encadré "★ À RETENIR" | Fond jaune | Résume les règles essentielles à mémoriser |

Le contenu doit être rédigé intégralement (voir règle de rédaction dans SKILL.md) — pas de placeholders, pas de méta-instructions.

---

## 6. Table des matières et organisation par thèmes

Le manuel est organisé en **thèmes/périodes**, chacun regroupant plusieurs séances consécutives.

### Table des matières

```
THÈME [N] — [NOM DU THÈME]  Séances [X] à [Y]
  Séance [n] — [Titre de la séance]  [Sous-discipline]
  ...
```

### Page de séparation par thème (avant la première séance du thème)

Contient :
1. **Tableau de bord de la période** : tableau récapitulatif (N°, Titre de la séance, Sous-discipline, Durée) pour toutes les séances du thème
2. **Compétences visées** : liste des compétences que l'élève doit acquérir sur la période
3. **Notions grammaticales et lexicales** (ou équivalent selon la matière) : liste des notions couvertes

Si le manuel est destiné à un usage pluriannuel (validé à l'Étape 0 de SKILL.md), omettre toute référence à un mois ou une date calendaire sur cette page ; n'afficher que la plage de séances (ex : "Séances S1 à S5"), jamais "1er mois" ni de dates.

Le titre de la période (`PÉRIODE [N]` ou `THÈME [N]`) doit utiliser le style Word **Heading 1**, en plus de sa mise en forme visuelle (couleur, taille) — voir section 8 pour le même principe appliqué aux séances.

---

## 7. Annexes

**Toujours demander à l'utilisateur, matière par matière, quelles annexes s'appliquent** (ex : les tableaux de conjugaison n'ont pas de sens en Maths/SVT ; un glossaire grammatical n'a pas de sens en EPS). Ne jamais inclure une annexe non pertinente pour la matière sans validation.

Annexes courantes observées (à adapter selon la matière) :

| Annexe | Contenu | Pertinent pour |
|--------|---------|-----------------|
| Tableaux de conjugaison | Verbes du programme, temps étudiés | Langues (Français, Malgache, Anglais…) |
| Glossaire de termes | Termes techniques/clés avec définitions | Toutes matières, adapté au vocabulaire de la matière |
| Grilles d'auto-évaluation élève | Une grille par thème, cases à cocher | Toutes matières |
| Index des notions par séance | Table de correspondance notion → séance | Toutes matières |
| Évaluations format examen | Devoirs types avec corrigés, alignés sur l'examen national du niveau | Toutes matières, adapté au format d'examen réel (ex : "Sujet d'examen [niveau]") |

---

## 8. Séance complète en Traitement B — ordre des blocs

1. **En-tête de séance** : `SÉANCE [N] — [TITRE]` + ligne de séparation. Ce titre doit utiliser le style Word **Heading 2** (en plus de sa mise en forme visuelle), pour que le document soit navigable dans le volet de navigation Word. En python-docx : `doc.add_paragraph(style='Heading 2')`. En XML brut : `<w:pStyle w:val="Heading2"/>` dans le `<w:pPr>` du paragraphe. Les titres de période (section 6) utilisent de la même façon le style **Heading 1**.
2. **Fiche de préparation** numérotée `n° [N]/[Total]` (structure détaillée : [`design-fiche.md`](design-fiche.md))
3. **Contenu de la leçon** à copier dans le cahier (conventions section 5)
4. **Exercices** — plusieurs exercices variés, barème total sur 20 points, répartition affichée (ex : Ex. 1 : 6 pts / Ex. 2 : 8 pts / Ex. 3 : 6 pts). Contenu réel rédigé (voir règle de rédaction dans SKILL.md).
5. **Correction complète** avec barème détaillé, immédiatement après les exercices. **Jamais de barème seul** : chaque exercice de production (lettre, CV, paragraphe, plan, phrase rédigée...) doit recevoir un modèle rédigé réel en plus de la répartition des points. Un corrigé qui ne liste que les points ("2 pts, 2 pts, 2 pts") sans exemple de réponse rédigée est un manquement à la règle de rédaction (SKILL.md, "contenu réel, jamais méta-instructions") — se relire spécifiquement sur ce point avant livraison.

Pour les séances d'évaluation (voir SKILL.md), remplacer les blocs 3-4-5 par un sujet d'évaluation complet + corrigé, sans fiche de préparation ni contenu de leçon.

---

## 9. Ce qu'il ne faut PAS inventer

- Coordonnées de contact (email, adresse) — demander à l'utilisateur
- Année d'édition si non précisée — demander à l'utilisateur
- Annexes non validées par l'utilisateur pour la matière concernée
- Contenu de programme non couvert par le document RAPS fourni, sans validation explicite d'une recherche complémentaire (voir Étape 0, question 2)
