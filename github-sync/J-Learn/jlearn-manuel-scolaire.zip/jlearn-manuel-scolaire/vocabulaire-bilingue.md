# Vocabulaire bilingue — Français / Malgache

Référence pour produire la version malgache de la fiche de préparation.
Source : fichiers officiels J-Learn uploadés par l'utilisateur.

---

## Titre du document

| Français | Malgache |
|---------|---------|
| FICHE DE PRÉPARATION | TAKELA-PANOMANAN-DESONA |

---

## Méta-table

| Français | Malgache |
|---------|---------|
| Discipline | Taranja |
| Sous discipline | Zana-taranja |
| Thème | Lohahevitra |
| Titre | Lohateny |
| Objectif spécifique | Tanjona manokana |
| Documentation | Fanovozan-kevitra |
| Support et matériel | Fitaovana |
| Date | Daty |
| Classe | Kilasy |
| Séance n° | Seho n° |
| Durée | Faharetany |
| min / minutes | minitra |

---

## Colonnes de la table de déroulement

| Français | Malgache |
|---------|---------|
| Étapes et Durée | Dingana sy Faharetany |
| Déroulement de la leçon | Fizotry ny Lesona |
| Enseignant | Mpampianatra |
| Apprenants | Mpianatra |
| Technique et Stratégie | Tetika Amam-paika |
| Support et matériel | Fitaovana |
| Observation | Fanamarihana |

---

## Phases (lignes grises)

| Français | Malgache |
|---------|---------|
| 1. RÉVISION — … min | 1. FAMERENANA — … minitra |
| 2. NOUVELLE LEÇON — … min | 2. LESONA VAOVAO / NOUVELLE LEÇON — … minitra |
| 3. Évaluation / … min | 3. TOMBANA / … minitra |

---

## Sous-étapes de la NOUVELLE LEÇON

| Français | Malgache |
|---------|---------|
| 2.1 Mise en Situation | 2.1 Fitarihan-tsaina |
| 2.2 Présentation | 2.2 Fanolorana |
| 2.3 Observation | 2.3 Fandinihana |
| 2.4 Analyse | 2.4 Famakafakana |
| 2.5 Synthèse | 2.5 Fandravonana |
| 2.6 Application | 2.6 Fampiharana |

---

## Termes courants dans les cellules

| Français | Malgache |
|---------|---------|
| Répondent | Mamaly |
| Réponse Attendue (R.A.) | Valiny Andrasana (V.A.) |
| Question réponse | Fanontaniana sy Valiny (F/V) |
| Travail collectif | Asa iombonana (Travail collectif) |
| Travail individuel | Asa tsirairay (travail individuel) |
| Brainstorming | Brainstorming / Tosa-kevitra |
| Par binôme ou trinôme / par groupe | Isan-dabilio / Isan-tarika (par groupe) |
| Écoutent | Mihaino |
| Regardent | Mijery / Mandinika |
| Copient dans leur cahier | Mandika |
| Répètent / Écrivent / Montrent / Font l'exercice | Mamerina / Manoratra / Maneho / Miasa |
| Image / texte, objet | Sary / lahatsoratra … |
| Évaluation | Tombana |
| RÉVISION | FAMERENANA |

---

## Termes de la zone RÉVISION (cellule Enseignant)

FR : *Posez des questions ou faites réciter oralement, ou faites écrire aux apprenants [selon la discipline concernée] des éléments en lien avec la dernière leçon vue.*

MG : *Mametraka fanontaniana na mampa merina mitanisa am-bava na mampanoratra mpianatra [arakaraka ny taranja natao] zavatra mifandray amin'ny lesona natao farany.*

---

## Termes de la zone ÉVALUATION

FR (Enseignant) : *On procède généralement par des questions orales ou des exercices écrits. C'est ici que l'on mesure la compréhension des apprenants.*

MG : *Fanontaniana am-bava na fampiasana an-tsoratra matetika no atao ato. Eto no handrefesana ny fahatakaran'ny mpianatra.*

FR (Apprenants) : *Répondent. (travail individuel)*

MG : *Mamaly. Asa tsirairay (travail individuel)*

---

## Manuel complet (Traitement B) — termes structurels

À utiliser uniquement quand une version malgache du manuel complet est demandée.

| Français | Malgache |
|---------|---------|
| Manuel de [Matière] | Boky [Taranja] |
| Classe de [Niveau] | Kilasy [Niveau] |
| Avant-propos | Teny fanolorana |
| Comment utiliser ce manuel | Ahoana ny fampiasana ity boky ity |
| Table des matières | Fizahan-takila / Rejim-bontoatiny |
| Thème | Lohahevitra |
| Séance | Seho |
| Compétences visées | Fahaiza-manao tanjona |
| Notions grammaticales et lexicales | Foto-kevitra ara-teny sy ara-bakabolana |
| Exercices | Fanazaran-tena |
| Corrigé / Correction | Valin'ny fanazaran-tena |
| Annexes | Tovana |
| Glossaire | Rakibolana |
| Index | Fizahan-teny |
| Évaluation format examen | Fitsapana endrika fanadinana |

**Note** : cette liste est indicative — vérifier/compléter avec l'utilisateur si des termes plus précis existent déjà dans les fichiers officiels J-Learn pour la matière concernée.
