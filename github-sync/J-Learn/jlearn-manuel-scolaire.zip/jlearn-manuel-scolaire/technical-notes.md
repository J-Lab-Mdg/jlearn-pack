# Notes techniques — Traitement des .docx J-Learn

Ces notes sont internes : ne pas les expliquer mot pour mot à l'utilisateur (simplifier le langage).

---

## Stack technique

- **Langage** : Node.js
- **Librairie** : `adm-zip` (lecture/écriture des fichiers .docx qui sont des archives ZIP)
- **Extension des scripts** : `.cjs` (obligatoire car `scripts/package.json` a `"type": "module"`)
- **Emplacement des scripts** : `scripts/` à la racine du projet

### Installation de adm-zip si absente
```bash
cd scripts && npm install adm-zip
```

---

## Principe de modification du .docx

Un fichier `.docx` est une archive ZIP contenant `word/document.xml`.  
Le script :
1. Extrait `word/document.xml` en mémoire
2. Applique des modifications ciblées sur le XML (string-replacement positionnel)
3. Réemballe le tout dans un nouveau `.docx`

---

## Sauvegarde obligatoire avant toute modification

**Avant de lancer tout script de transformation, copier le `.docx` source intact** (ex : `[nom]_ORIGINAL_BACKUP.docx`) dans un dossier de travail temporaire.  
En cas d'échec des vérifications post-génération (voir SKILL.md), c'est cette copie — jamais le fichier partiellement modifié — qui doit être présentée à l'utilisateur.

---

## Validation préalable — détection de tableaux imbriqués

Avant de lancer le script principal sur un nouveau `.docx` source, vérifier s'il contient des tableaux imbriqués (un `<w:tbl>` à l'intérieur d'un `<w:tc>`), car le parsing par regex ne les gère pas correctement (voir limitation ci-dessous).

```javascript
// Détection simplifiée : compter les <w:tbl> puis vérifier s'il y en a
// entre l'ouverture d'un <w:tc> et sa fermeture correspondante.
// Si trouvé : alerter l'utilisateur avant de lancer le script, ne pas
// traiter automatiquement cette séance.
```

Si des tableaux imbriqués sont détectés, ne pas tenter le traitement automatique sur la ou les séances concernées — le signaler à l'utilisateur et traiter manuellement ou au cas par cas.

---

## Règle critique — Ne jamais reconstruire le body entier

**Approche correcte : string-replacement ciblé**

```
raw = bodyXml complet
Trouver la position [bs..be] de la zone à modifier
newBody = raw[0..bs] + éléments modifiés + raw[be..]
```

Le suffixe `raw[be..]` contient `</w:body></w:document>` et surtout `<w:sectPr>` (propriétés de page).  
**Si on utilise une approche qui reconstruit le body depuis une liste d'éléments parsés, on perd `<w:sectPr>` → corruption du document.**

Appliquer les remplacements de droite à gauche (positions décroissantes) pour que les offsets des remplacements précédents ne soient pas décalés.

---

## Parsing XML simplifié (sans librairie XML)

Les scripts utilisent des regex et des recherches de chaînes pour repérer les éléments Word :
- `<w:tbl>` → tableau
- `<w:tr>` → ligne de tableau
- `<w:tc>` → cellule
- `<w:p>` → paragraphe
- `<w:t>` → texte

**Limitation** : ne gère pas correctement les tableaux imbriqués. Si le docx source contient des tableaux dans des cellules, la détection de frontières peut échouer. Dans ce cas, traiter manuellement ou ajouter une vérification en amont.

---

## Structure des scripts par manuel

| Script | Rôle |
|--------|------|
| `transform_[niveau].cjs` | Enrichissement 2.5/2.6 pour un niveau donné |
| `patch_[niveau].cjs` | Corrections complémentaires pour séances spéciales |
| `fix_[niveau]_design.cjs` | Corrections design (titre, police, 6 colonnes, lignes grises) |

### Séances spéciales (patch séparé)
Certaines séances ont une structure XML différente des autres (ex : 3e → S13, S18, S21, S25).  
Ces séances nécessitent un script de patch séparé car leur structure interne diverge du pattern général.  
Identifier ces cas en inspectant le XML des séances après le premier passage du script principal.

---

## Vérifications post-génération (à afficher à l'utilisateur)

```javascript
// Après génération, lire le XML du nouveau docx et vérifier :
const sectPrCount = (xml.match(/<w:sectPr[\s>]/g) || []).length;
const ns0Count    = (xml.match(/\bns0:/g) || []).length;
// sectPrCount doit être === 1
// ns0Count doit être === 0
// Sinon : process.exit(1) avec message d'erreur explicite
```

---

## Namespaces Word

Le fichier `.docx` doit conserver exactement 32 namespaces dans la balise `<w:document>`.  
Toute reconstruction du XML qui perd des namespaces produit un fichier corrompu à l'ouverture dans Word.  
**Solution** : ne jamais réécrire la balise `<w:document …>` — la conserver intacte depuis le fichier source.

---

## Nommage des fichiers de sortie (rappel)

```
Manuel_[Matière]_[Niveau]_V[N]_[ETAPE].docx
```
- `ETAPE` = `AMELIORE` (enrichissement), `DESIGN` (design corrigé)
- `V[N]` = numéro de version incrémental

Exemple complet : `Manuel_Francais_4e_V2_DESIGN.docx`
