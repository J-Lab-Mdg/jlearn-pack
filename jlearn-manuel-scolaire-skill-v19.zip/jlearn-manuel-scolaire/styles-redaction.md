# Styles rédactionnels — choix obligatoire & garde-fous anti-« effet IA »

Fichier ajouté en v19 à la suite d'un retour utilisateur (oct. 2026) : les manuels produits avaient un rendu « trop IA » — encadrés systématiques, métaphores filées répétées d'unité en unité, ton exclamatif uniforme, méta-mentions inutiles. Ce fichier **n'annule aucune règle existante** : il ajoute un choix de style au démarrage et des garde-fous valables pour tous les styles.

**Principe directeur** : un manuel scolaire est écrit pour des humains, par imitation de la façon de faire des bons auteurs humains (leur manière de rédiger, leur perspective — pas leurs imperfections). Rien ne s'applique sans validation de l'utilisateur.

---

## 1. Question de choix (à ajouter à l'Étape 0)

À la création de **tout nouveau manuel** (et avant tout retrofit de style sur un manuel existant), poser la question :

> « Quel style rédactionnel pour ce manuel ? »
> - **Style A — Classique sobre** (type manuel d'éditeur / programme officiel)
> - **Style B — J-Learn narratif illustré** (style historique de la collection)
> - **Hybride** (à définir ensemble : par ex. ouvertures d'unité sobres + leçons narratives allégées)

Montrer un **mini-échantillon** de chaque style (quelques lignes) pour que le choix soit éclairé. Ne jamais supposer le style ; ne jamais mélanger deux styles dans un même manuel sans validation.

---

## 2. Style A — Classique sobre

Modèle : la page de contenus d'unité des manuels d'éditeurs et des programmes officiels. Exemple validé par l'utilisateur :

```
UNIT 1   OUR TIME

VOCABULARY
- WH-questions and how
- Adjectives to describe past events
- Positive feelings.
- Negative feelings.

GRAMMAR:
    Exclamatory form with what a, how (What a beautiful day!)
    Past continuous (long past action) vs Past simple (short past action)
    "Used to…" for past habits; in all forms
    Linking words to express contrast: but, whereas, however, etc.
    The structure of a paragraph
      - A topic sentence
      - Arguments
      - A restatement sentence
```

Caractéristiques :
- **Ouverture d'unité** = sommaire sec des contenus (rubriques + tirets), sans bannière-slogan, sans encadré « Why this unit », sans phrase d'accroche exclamative.
- **Leçons** : titre + contenu direct. Listes sans contour par défaut. Tableaux réservés aux paradigmes (conjugaison, déclinaison de formes). **0 à 1 encadré par leçon maximum** (règle centrale ou document modèle).
- **Ton neutre et professionnel** : pas de métaphores filées, pas de jeux nommés, pas de slogans, très peu de points d'exclamation (≤ 1 par page).
- Les exemples restent concrets et locaux (contexte malgache), mais formulés simplement.
- La fiche de préparation garde sa structure officielle (design-fiche.md) — le style ne concerne que la **rédaction** (ton, dispositifs, habillage des leçons et pages d'unité).

## 3. Style B — J-Learn narratif illustré

Le style historique de la collection (bannières de couleur par unité, encadrés thématiques, accroches, page « I can… », mascottes, métaphores pédagogiques). Reste disponible tel quel — mais les garde-fous de la section 4 s'y appliquent aussi.

---

## 4. Garde-fous anti-« effet IA » (valables pour TOUS les styles)

1. **Un cadre doit se mériter.** Par défaut : liste ou paragraphe sans contour. Un encadré seulement pour un dialogue modèle, une règle centrale ou un document authentique simulé (lettre, annonce, bulletin). Jamais une leçon où presque chaque contenu est dans un cadre. Attention à l'excès inverse : zéro cadre partout est aussi une uniformité — c'est la **variation** qui fait humain.
2. **Une métaphore ne se systématise pas.** Interdire le motif « chaque notion = un objet » répété d'unité en unité (golden rule, magic words, secret tools, engines, medals…). Au plus une image pédagogique par unité, et seulement si elle aide réellement la mémorisation.
3. **Varier le rythme.** Alterner phrases courtes et longues ; éviter les triades systématiques (« clair, simple et poli ! ») et les séries de points d'exclamation.
4. **Varier réellement les dispositifs.** Ne pas resservir le même jeu sous un autre nom à chaque unité ; certaines étapes de pratique peuvent être un simple exercice écrit — comme dans un vrai manuel.
5. **Calibrage sur des manuels réels.** Avant un nouveau manuel, relire quelques pages d'un manuel réel du même niveau/matière (fourni par l'utilisateur de préférence) pour calibrer ton, densité et mise en page. S'inspirer de la **façon de rédiger**, jamais copier le contenu.
6. **Cahiers d'élèves scannés = référence prioritaire.** Si l'utilisateur fournit des cahiers scannés, les utiliser pour calibrer la trace écrite : longueur réelle d'une leçon copiée, présentation, ce qu'un enseignant écrit vraiment au tableau. Les demander quand ils seraient utiles.
7. **Sobriété des mentions dans le manuel.** Ne pas « tout annoncer » dans le manuel à chaque changement ou particularité (méta-commentaires d'édition, rappels de structure, notes sur ce qui a changé). Un éditeur humain ne met dans le livre que ce qui sert l'élève ou l'enseignant ; le reste va dans la conversation avec l'utilisateur. En cas de doute sur « faut-il le mentionner dans le manuel ? » → demander, ne pas insérer.
8. **Validation systématique.** Aucun changement de style — global ou local — appliqué à un manuel existant sans validation explicite. Un manuel entamé garde son style jusqu'à décision contraire. Pour « sobrer » un manuel existant : produire d'abord un **échantillon** (une leçon re-rédigée) et le faire valider avant tout retrofit.

---

## 5. Application à une collection existante

- La cohérence d'un manuel prime : pas de mélange A/B au milieu d'un tome sans décision de l'utilisateur.
- Un changement de style **entre deux tomes** d'une même collection est possible si l'utilisateur le valide (le noter dans la lettre de passation si travail multi-sessions).
- Lors d'un audit de conformité (audit-conformite.md), le style n'est **pas** un critère de non-conformité : on ne retrofitte jamais un style sans demande explicite.
