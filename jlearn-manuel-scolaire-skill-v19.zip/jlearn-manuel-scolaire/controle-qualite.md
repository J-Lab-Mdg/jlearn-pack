# Contrôle qualité automatisé avant livraison

Ce fichier regroupe les contrôles à passer **systématiquement** avant de livrer
un manuel. Ils ne remplacent pas la relecture, ils attrapent ce que la
relecture humaine laisse passer parce que l'erreur est répétitive et discrète.

---

## 1. Élision — l'erreur de gabarit la plus fréquente

### Le symptôme

    Objectif : Être capable de identifier les principales causes…
    Après cette séance vous serez capables de expliquer ce qu'est une addition…
    Objectif spécifique : Être capable de énumérer les organes du corps…

### La cause

Ce n'est **pas** une faute d'inattention isolée, c'est une faute de
**construction**. Une formule figée (`"Être capable de "`) est concaténée à un
fragment variable (l'objectif). Quand le fragment commence par une voyelle,
l'élision saute. L'erreur apparaît alors mécaniquement partout où la condition
est remplie — d'où des dizaines d'occurrences dans un même manuel.

Constat mesuré sur les livrables J-Learn existants :

| Manuel | occurrences |
|--------|-------------|
| `Manuel_Histoire_3e_VF_V1.docx` | 30 |
| `PE_T11.docx` | 102 |
| `Manuel_Calcul_9e_JLearn.docx` | 19 |
| `SVT-9e-Manuel-Complet.docx` | 12 |

### La correction — à la source, pas en relecture

Corriger les occurrences une à une garantit que l'erreur reviendra à la
génération suivante. **Il faut élider dans la fonction qui assemble la
formule**, jamais en aval :

```python
def elide(particule, suite):
    """« de » + « identifier » -> « d'identifier ». Le h aspiré est ignoré
    volontairement : il est rare dans les objectifs pédagogiques et une
    élision fautive y serait plus visible qu'une absence d'élision."""
    if suite[:1].lower() in "aeiouâàäéèêëîïôöûü":
        return particule[:-1] + "'" + suite
    return particule + " " + suite

objectif = "Être capable " + elide("de", verbe)
```

Les mêmes couples sont concernés : `de/d'`, `que/qu'`, `ne/n'`, `se/s'`,
`je/j'`, `la/l'`, `le/l'`, `ce/c'`, `si il/s'il`.

### Le contrôle

```bash
python3 scripts/lint_langue.py Manuel-XXX.md        # ou .docx
```

Le script sort en code 1 si une anomalie subsiste. Il couvre aussi les doubles
espaces et les espaces avant ponctuation.

**Attention aux fausses alertes** — un contrôle naïf `\bla [voyelle]` signale à
tort les pronoms enclitiques, qui sont corrects :

    Exprime-la en pourcentage.      correct
    Compare-le au besoin.           correct
    Est-ce un animal ?              correct
    La réponse est le B.            correct

Le linter les écarte par un `(?<![\w-])` devant le motif et une exception sur
les lettres-étiquettes. Ne jamais « corriger » ces formes.

---

## 2. Code couleur — le gras ne suffit pas

Le gras seul ne distingue pas un mot clé d'une simple emphase. Le code couleur
du skill doit être **réellement présent dans le `.docx`**, pas seulement décidé
sur le papier.

| Élément | Couleur | Code |
|---------|---------|------|
| Titre de la leçon | Rouge | `#C00000` |
| Sous-titres de la leçon | Vert | `#1E7B34` |
| Mots clés de la leçon | Bleu + gras | `#1F4E79` |
| Mots clés du corrigé | Rose/bordeaux + gras | `#C2185B` |
| Texte courant | Noir | `#000000` |

Contrôle :

```bash
python3 - <<'PY'
import zipfile, re, collections
x = zipfile.ZipFile("Manuel-XXX.docx").read("word/document.xml").decode("utf8")
print(collections.Counter(re.findall(r'w:color w:val="([0-9A-Fa-f]{6})"', x)))
PY
```

Les quatre codes doivent apparaître. **Si `1F4E79` ou `C2185B` est absent, le
code couleur n'est pas appliqué** — c'était le cas du manuel SVT T9 jusqu'à sa
révision : seuls le rouge et le vert des titres sortaient, les mots clés
restaient en gras noir.

Le gras ne doit être coloré que dans la leçon et le corrigé. Dans la fiche de
préparation et les énoncés d'exercices, il reste noir : y appliquer le bleu
transformerait chaque `**Donc,**` de la colonne Synthèse en faux mot clé.

Piège rencontré : normaliser un titre par `titre.upper().replace("É", "E")`
ne retire pas la cédille, et `"PAGE LEÇON"` ne correspond alors jamais à
`"PAGE LECON"`. Utiliser `unicodedata.normalize("NFD", …)` et traiter le `Ç`.

---

## 3. Exactitude du contenu

Toute donnée chiffrée, norme ou recommandation citée dans une leçon est
vérifiée en ligne avant livraison, et la source part en bibliographie
(règle critique 13).

Sont particulièrement à vérifier, parce qu'ils datent vite ou circulent sous
des versions périmées :

- les recommandations sanitaires (durées de sommeil, apports nutritionnels,
  âges de vaccination) ;
- les seuils, taux et statistiques ;
- les délais et durées biologiques.

**Le fascicule officiel n'est pas une autorité suffisante à lui seul.** Deux cas
réels rencontrés dans le programme SVT T9 :

- le fascicule indique 20 h de sommeil pour le nouveau-né, là où la National
  Sleep Foundation retient 14 à 17 h ;
- il range la salivation devant un citron coupé à la fois dans les réflexes
  innés et dans les réflexes acquis, ce qui est contradictoire.

Dans les deux cas, la bonne conduite est de retenir la donnée juste **et de
signaler l'écart dans une note du manuel**, plutôt que de recopier la source ou
de la corriger en silence.

---

## 4. Leçon directement copiable

Le texte de la leçon doit pouvoir être recopié tel quel dans le cahier de
l'élève : phrases complètes, autonomes, sans renvoi au manuel.

**Ne jamais écrire la consigne elle-même dans la leçon** — pas de « à recopier »,
« copiez ce qui suit », « leçon à noter ». La leçon est copiable par sa forme,
et le dire dans le texte l'abîme.

À proscrire dans le corps de la leçon :

- les renvois au support : « comme on l'a vu plus haut », « voir le schéma
  ci-dessus » sans reprise de l'information ;
- les méta-instructions : « l'enseignant expliquera que… » ;
- les phrases suspendues qui n'ont de sens qu'à l'oral.

L'indication de ce que font les élèves reste **dans la colonne Apprenant de la
fiche** (« Les élèves recopient. »), jamais dans la leçon.

---

## 5. Séquence complète avant livraison

```bash
python3 scripts/assembler_manuel.py          # réassemble depuis les unités
python3 scripts/md2docx.py Manuel.md Manuel.docx
python3 scripts/verifier_manuel.py           # contrôles de structure
python3 scripts/lint_langue.py Manuel.md     # langue et typographie
python3 scripts/check_plagiat.py             # anti-plagiat
```

Après toute correction typographique, **corriger le fichier source d'unité et
réassembler** — corriger seulement le manuel assemblé le fait diverger de ses
sources, ce que `verifier_manuel.py` détecte et refuse.
